# -*- coding: utf-8 -*-
"""truntime —— runtime.py 的 torch 移植：post / quantize / 渲染循环（DEVICE 可选 cuda）。

用法:
  python truntime.py verify            # 抽帧与 ../frames_ep01 参考帧对比 PSNR
  python truntime.py bench [N]         # 单进程渲染 N 帧（默认 24），报 fps
  python truntime.py render A B        # 渲第 A..B 帧 -> frames_t_ep01/
"""
import os
import sys
import time

import numpy as _np
import torch
from PIL import Image

import tcommon as C
from tcommon import W, H, FPS, bloom, clamp01, ease_io

TL_BEAT = 0.75
DITHER_SEED = _np.random.default_rng(2026)   # 与 CPU 版同种子同消耗序 → 逐帧抖动一致

DEVICE = "cpu"

def set_device(d):
    global DEVICE
    DEVICE = d
    C.set_device(d)

def _vignette():
    C._ensure_grid()
    return C.VIGNETTE

def apply_zoom(frame, zoom):
    if zoom <= 1.002:
        return frame
    cw = int(W / zoom); ch = int(H / zoom)
    x0 = (W - cw) // 2; y0 = (H - ch) // 2
    crop = frame[y0:y0 + ch, x0:x0 + cw, :].permute(2, 0, 1)[None]   # (1,3,ch,cw)
    out = torch.nn.functional.interpolate(crop.float(), size=(H, W), mode="bilinear",
                                          align_corners=False, antialias=True)
    return out[0].permute(1, 2, 0)

def load_episode(name):
    import importlib
    mod = importlib.import_module(f"episodes_t.{name}")
    shots, t = [], 0.0
    for s in mod.SCENES:
        dur = s["dur"]
        shots.append(dict(name=s["name"], start=t, dur=dur, end=t + dur,
                          trans=s.get("trans", "flash"), energy=s.get("energy", 0.5),
                          chapter=s.get("chapter")))
        t += dur
    total = getattr(mod, "TOTAL", None) or t
    return mod, shots, total

def shot_at(shots, t):
    for s in shots:
        if t < s["end"]:
            return s
    return shots[-1]

def post(frame, t, shots, ep_name):
    s = shot_at(shots, t)
    tl = t - s["start"]
    dur = s["dur"]
    idx = shots.index(s)
    energy = s["energy"]
    z0 = 1.045 if idx % 2 else 1.0
    z1 = 1.0 if idx % 2 else 1.045
    if s["name"] in ("opening", "cold_open"):
        z0, z1 = 1.0, 1.08
    zoom = z0 + (z1 - z0) * float(ease_io(tl / dur))
    frame = apply_zoom(frame, zoom)
    frame = bloom(frame, thr=0.52, strength=0.55 + 0.55 * energy, radius=12)
    ph = (t % TL_BEAT) / TL_BEAT
    pulse = _np.exp(-ph * TL_BEAT / 0.085).astype(_np.float32)
    frame = frame * (1.0 + 0.055 * pulse * float(clamp01((energy - 0.3) * 2.4)))
    frame = frame * _vignette()
    lum = frame.mean(-1, keepdim=True)
    frame = lum + (frame - lum) * 1.07
    frame = frame + torch.tensor([0.002, 0.004, 0.010], device=frame.device)
    tr = s["trans"]
    if tr == "fade":
        frame = frame * float(clamp01(t / 2.2))
    elif tr == "dip":
        frame = frame * float(ease_io(clamp01(tl / 0.7)))
    elif tr == "flash":
        add = torch.tensor([0.62, 0.68, 0.85], device=frame.device)
        frame = frame + add * _np.exp(-tl / 0.16).astype(_np.float32) * 0.5
    elif tr == "cut":
        if tl < 0.05:
            add = torch.tensor([0.3, 0.33, 0.42], device=frame.device)
            frame = frame + add * _np.exp(-tl * 30).astype(_np.float32) * 0.9
    nxt = shots[idx + 1] if idx + 1 < len(shots) else None
    if nxt is not None:
        if nxt["trans"] == "dip":
            frame = frame * float(ease_io(clamp01((dur - tl) / 0.7)))
        elif nxt["trans"] == "flash":
            g = float(clamp01((tl - (dur - 0.45)) / 0.45))
            add = torch.tensor([0.5, 0.55, 0.72], device=frame.device)
            frame = frame + add * (g ** 2) * 0.42
    else:
        total = shots[-1]["end"]
        frame = frame * float(clamp01((total - t) / 1.2))
    return frame

def quantize(frame):
    frame = frame.clamp(0, 1)
    d = DITHER_SEED.random((H, W, 1), dtype=_np.float32)
    frame = frame + (torch.from_numpy(d).to(frame.device) - 0.5) * (1.6 / 255)
    return C.to_u8(frame)

def render_by_time(mod, shots, t):
    s = shot_at(shots, t)
    fn = getattr(mod, "scene_" + s["name"])
    frame = fn(t - s["start"], s["dur"])
    return quantize(post(frame, t, shots, mod.__name__.split(".")[-1]))

def sync():
    if DEVICE != "cpu":
        torch.cuda.synchronize()

# ---------------- 命令行 ----------------
def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "bench"
    if cmd == "cuda":
        set_device("cuda"); cmd = sys.argv[2] if len(sys.argv) > 2 else "bench"
    mod, shots, total = load_episode("ep01")
    print(f"[ep01] {getattr(mod,'TITLE','')}  shots={len(shots)}  total={total}s  device={DEVICE}"
          + (f"  ({torch.cuda.get_device_name(0)})" if DEVICE != "cpu" else ""))

    if cmd == "verify":
        ref_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "frames_ep01")
        import math
        idxs = list(range(0, int(total * FPS), 450))
        t0 = time.time()
        psnrs = []
        for i in idxs:
            arr = render_by_time(mod, shots, min(i / FPS, total - 0.1))
            ref = _np.asarray(Image.open(os.path.join(ref_dir, f"f{i:05d}.jpg")), _np.float32)
            mse = ((arr.astype(_np.float32) - ref) ** 2).mean()
            psnrs.append(10 * math.log10(1.0 / mse) if mse > 0 else 99)
            print(f"  f{i:05d}  PSNR {psnrs[-1]:.1f} dB")
        print(f"verify: n={len(psnrs)}  min={min(psnrs):.1f}  mean={sum(psnrs)/len(psnrs):.1f} dB  ({time.time()-t0:.0f}s)")

    elif cmd == "bench":
        n = int(sys.argv[2]) if len(sys.argv) > 2 else 24
        idxs = [int(i * total * FPS / n) for i in range(n)]
        for i in idxs[:2]:   # 预热（精灵/噪声/编译缓存）
            render_by_time(mod, shots, min(i / FPS, total - 0.1))
        sync(); t0 = time.time()
        for i in idxs:
            arr = render_by_time(mod, shots, min(i / FPS, total - 0.1))
        sync(); el = time.time() - t0
        fps = len(idxs) / el
        print(f"bench: {len(idxs)} frames in {el:.1f}s -> {fps:.2f} fps "
              f"(一集 {int(total*FPS)} 帧 ≈ {int(total*FPS/fps/60)} 分钟)")

    elif cmd == "render":
        a = int(sys.argv[2]); b = int(sys.argv[3])
        out_dir = "frames_t_ep01"
        os.makedirs(out_dir, exist_ok=True)
        t0 = time.time()
        for i in range(a, b + 1):
            arr = render_by_time(mod, shots, min(i / FPS, total - 0.1))
            Image.fromarray(arr).save(f"{out_dir}/f{i:05d}.jpg", quality=92, subsampling=0)
            if (i - a) % 50 == 0:
                sync()
                print(f"  {i}/{b}  {time.time()-t0:.0f}s", flush=True)
        print(f"render done: frames {a}..{b} in {time.time()-t0:.0f}s")

if __name__ == "__main__":
    main()
