# -*- coding: utf-8 -*-
"""把 episodes/epNN.py 和 llm_common.py 转成 torch 版（只换导入与 .astype）。

用法: python convert_episode.py ep01
生成: episodes_t/ep01.py（首次会一并生成 llm_common_t.py 与 __init__.py）
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "..")

def convert(text):
    text = text.replace("import numpy as np", "import tnp as np")
    text = text.replace("from common import *", "from tcommon import *")
    text = text.replace("from llm_common import *", "from llm_common_t import *")
    text = re.sub(r"from common import \(", "from tcommon import (", text)
    # .astype(dtype) -> .to(dtype)（torch 无 astype；dtype 名在 tnp/tcommon 语义下一致）
    text = re.sub(r"\.astype\(", ".to(", text)
    return text

def main():
    name = sys.argv[1] if len(sys.argv) > 1 else "ep01"
    eps_t = os.path.join(HERE, "episodes_t")
    os.makedirs(eps_t, exist_ok=True)
    open(os.path.join(eps_t, "__init__.py"), "w").close()

    if not os.path.exists(os.path.join(HERE, "llm_common_t.py")):
        src = open(os.path.join(SRC, "llm_common.py"), encoding="utf-8").read()
        open(os.path.join(HERE, "llm_common_t.py"), "w", encoding="utf-8").write(convert(src))
        print("written llm_common_t.py")

    src = open(os.path.join(SRC, "episodes", f"{name}.py"), encoding="utf-8").read()
    open(os.path.join(eps_t, f"{name}.py"), "w", encoding="utf-8").write(convert(src))
    print(f"written episodes_t/{name}.py")

if __name__ == "__main__":
    main()
