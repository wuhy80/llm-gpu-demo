# -*- coding: utf-8 -*-
"""tnp —— torch 伪装 numpy 的兼容垫片。

用途：让 episodes/epNN.py 与 llm_common.py 里的 numpy 代码零改动跑在 torch 上（CPU 或 CUDA）。
只覆盖本项目实际用到的 numpy API 面（2026-10 审计）：
  float32/float64/pi, sin, cos, exp, abs, sqrt, hypot, tile, diff, where, roll,
  array, asarray, zeros, zeros_like, ones, full, empty_like, stack, concatenate,
  linspace, arange, clip, maximum, minimum, mean, interp, mgrid, meshgrid,
  add(out=), linalg.norm, random.default_rng(uniform/normal/integers/random)

随机数刻意走「真 numpy」再转 tensor：保证与 CPU 版逐帧一致（星星位置/噪声场相同），
PSNR 可以严格对参考帧校验。
"""
import math

import numpy as _np
import torch

# ---- dtype / 常量 ----
float32 = torch.float32
float64 = torch.float64
int32 = torch.int32
int64 = torch.int64
uint8 = torch.uint8
pi = math.pi
newaxis = None

# ---- 标量感知的数学函数（python float 走 math，tensor 走 torch） ----
def _sf(f_math, f_torch):
    def g(x, *rest):
        if isinstance(x, (int, float)):
            return f_math(x, *rest) if rest else f_math(x)
        return f_torch(x)
    return g

sin = _sf(math.sin, torch.sin)
cos = _sf(math.cos, torch.cos)
exp = _sf(math.exp, torch.exp)
sqrt = _sf(math.sqrt, torch.sqrt)
abs = _sf(abs, torch.abs)

def hypot(a, b):
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return math.hypot(a, b)
    return torch.hypot(torch.as_tensor(a, _DEVICE), torch.as_tensor(b, _DEVICE))
def tile(x, reps=None, *a, **kw):
    if not isinstance(x, torch.Tensor):
        x = asarray(x)
    if reps is None:
        return x
    if isinstance(reps, int):
        reps = (reps,)
    return torch.tile(x, tuple(reps))
diff = torch.diff
where = torch.where
roll = torch.roll
stack = torch.stack
clamp = torch.clamp
clip = torch.clamp
maximum = torch.maximum
minimum = torch.minimum
arange = torch.arange
linspace = torch.linspace
zeros_like = torch.zeros_like
ones_like = torch.ones_like
empty_like = torch.empty_like
as_tensor = torch.as_tensor

_DEVICE = "cpu"

def set_device(d):
    global _DEVICE
    _DEVICE = d

def dev():
    return _DEVICE


# ---- 构造（把标量 shape 归一成 tuple） ----
def _sz(shape):
    if isinstance(shape, (tuple, list)):
        return tuple(shape)
    return (shape,)

def zeros(shape, dtype=torch.float32, *a, **kw):
    return torch.zeros(_sz(shape), dtype=dtype, device=_DEVICE)

def ones(shape, dtype=torch.float32, *a, **kw):
    return torch.ones(_sz(shape), dtype=dtype, device=_DEVICE)

def full(shape, val, dtype=torch.float32, *a, **kw):
    return torch.full(_sz(shape), float(val), dtype=dtype, device=_DEVICE)

def empty(shape, dtype=torch.float32, *a, **kw):
    return torch.empty(_sz(shape), dtype=dtype, device=_DEVICE)

def _plain(x):
    """把嵌套 tensor 的 list/tuple 摊平成纯 Python 值（torch.tensor 只吃原生序列）"""
    if isinstance(x, torch.Tensor):
        return x.item() if x.numel() == 1 else x.tolist()
    if isinstance(x, (list, tuple)):
        return type(x)(_plain(e) for e in x)
    return x

def array(x, dtype=None, *a, **kw):
    if isinstance(x, torch.Tensor):
        return x.to(dtype=dtype) if dtype is not None else x
    if isinstance(x, (list, tuple)):
        x = _plain(x)
    t = torch.tensor(x, device=_DEVICE)
    return t.to(dtype) if dtype is not None else t

def asarray(x, dtype=None, *a, **kw):
    if isinstance(x, torch.Tensor):
        return x.to(dtype=dtype) if dtype is not None else x
    if isinstance(x, _np.ndarray):
        t = torch.from_numpy(x).to(_DEVICE)
    elif hasattr(x, "__array_interface__"):   # PIL.Image 等
        t = torch.from_numpy(_np.asarray(x)).to(_DEVICE)
    else:
        if isinstance(x, (list, tuple)):
            x = _plain(x)
        t = torch.tensor(x, device=_DEVICE)
    return t.to(dtype) if dtype is not None else t

def concatenate(seq, axis=0):
    return torch.cat(list(seq), dim=axis)

def mean(x, axis=None, keepdims=False):
    if axis is None:
        return x.mean()
    return x.mean(dim=axis, keepdim=keepdims)

def add(a, b, out=None):
    r = a + b
    if out is not None:
        out.copy_(r)
        return out
    return r


# ---- np.interp(x, xp, fp)：单调递增 xp 的一维线性插值 ----
def interp(x, xp, fp):
    xt = as_tensor(x).to(torch.float32).flatten()
    xpt = as_tensor(xp).to(torch.float32).flatten()
    fpt = as_tensor(fp).to(torch.float32).flatten()
    idx = torch.searchsorted(xpt, xt).clamp(1, len(xpt) - 1)
    x0, x1 = xpt[idx - 1], xpt[idx]
    f0, f1 = fpt[idx - 1], fpt[idx]
    w = ((xt - x0) / (x1 - x0)).clamp(0, 1)
    out = f0 + (f1 - f0) * w
    if isinstance(x, (int, float)) or (isinstance(x, torch.Tensor) and x.dim() == 0):
        return out[0]
    return out.reshape(as_tensor(x).shape)


# ---- np.mgrid[0:H, 0:W] / np.meshgrid(xy) ----
class _MGrid:
    def __getitem__(self, sl):
        rs = [torch.arange(s.start if s.start is not None else 0,
                           s.stop, s.step or 1, device=_DEVICE) for s in sl]
        grids = torch.meshgrid(*rs, indexing="ij")
        return torch.stack(grids, 0)

mgrid = _MGrid()

def meshgrid(*xs):
    return torch.meshgrid(*[as_tensor(x) for x in xs], indexing="xy")


# ---- linalg ----
class _Linalg:
    @staticmethod
    def norm(x, axis=None, *a, **kw):
        if axis is None:
            return torch.linalg.norm(x)
        return torch.linalg.norm(x, dim=axis, **({"keepdim": kw["keepdims"]} if "keepdims" in kw else {}))

linalg = _Linalg()


# ---- 随机数：真 numpy 流（保证与 CPU 版帧级一致）→ tensor ----
class _Rng:
    def __init__(self, seed=None):
        self._r = _np.random.default_rng(seed)

    @staticmethod
    def _to(t):
        if not isinstance(t, _np.ndarray):
            t = _np.asarray(t)
        return torch.from_numpy(t).to(_DEVICE)

    def random(self, size=None, dtype=None):
        n = None if size is None else _sz(size)
        return self._to(self._r.random(n).astype(_np.float32))

    def uniform(self, low=0.0, high=1.0, size=None):
        n = None if size is None else _sz(size)
        return self._to(self._r.uniform(low, high, n).astype(_np.float32))

    def normal(self, loc=0.0, scale=1.0, size=None):
        n = None if size is None else _sz(size)
        return self._to(self._r.normal(loc, scale, n).astype(_np.float32))

    def integers(self, low, high=None, size=None, *a, **kw):
        n = None if size is None else _sz(size)
        return self._to(self._r.integers(low, high, n)).to(torch.int64)

def default_rng(seed=None):
    return _Rng(seed)

class _RandomModule:
    default_rng = staticmethod(default_rng)

random = _RandomModule()
