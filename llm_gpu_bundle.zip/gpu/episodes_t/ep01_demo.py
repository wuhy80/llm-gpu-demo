# -*- coding: utf-8 -*-
"""EP01 前 3 个场景的 51 秒验证样片（GPU 管线端到端测试用）。
场景函数/字体/MUSIC 配置全部复用 ep01，仅裁剪时间线。"""
from episodes_t.ep01 import *          # noqa: F401,F403 —— 场景函数等全量复用

SCENES = [dict(s) for s in SCENES[:3]]  # cold_open 15s + opening 21s + chat 15s
TOTAL = sum(s["dur"] for s in SCENES)   # 51s -> 1530 帧 @30fps
