# -*- coding: utf-8 -*-
"""EP.01 一切从"猜下一个词"开始 —— 基准样片（360s / 6min / 80BPM 全小节对齐）"""
import tnp as np
from PIL import Image, ImageDraw
from tcommon import *
from llm_common_t import *

TITLE = "一切从「猜下一个词」开始"
SUB = "大模型到底在做什么"
EP_NO = 1

# ---------- 场景时长表（全部为 3s 整数倍） ----------
SCENES = [
    dict(name="cold_open",  dur=15, trans="fade",  energy=0.15),
    dict(name="opening",    dur=21, trans="dip",   energy=0.25, chapter=True),
    dict(name="chat",       dur=15, trans="flash", energy=0.40),
    dict(name="question",   dur=15, trans="flash", energy=0.45),
    dict(name="core_demo",  dur=39, trans="dip",   energy=0.60, chapter=True),
    dict(name="loop",       dur=24, trans="flash", energy=0.55),
    dict(name="temperature",dur=30, trans="flash", energy=0.60),
    dict(name="greedy",     dur=18, trans="flash", energy=0.45),
    dict(name="params",     dur=27, trans="dip",   energy=0.55, chapter=True),
    dict(name="layers",     dur=21, trans="flash", energy=0.50),
    dict(name="stages",     dur=21, trans="flash", energy=0.45),
    dict(name="not_retrieval", dur=21, trans="flash", energy=0.50),
    dict(name="why_powerful",  dur=27, trans="flash", energy=0.55),
    dict(name="limits",     dur=18, trans="dip",   energy=0.40, chapter=True),
    dict(name="knowledge_card", dur=24, trans="flash", energy=0.35),
    dict(name="preview",    dur=9,  trans="flash", energy=0.35),
    dict(name="endcard",    dur=15, trans="dip",   energy=0.15),
]
TOTAL = sum(s["dur"] for s in SCENES)

MUSIC = dict(
    beat=0.75, seed=101,
    chords=["Am", "F", "C", "G"],
    sub="A1",
    melody=[(87, 3, "E5"), (90, 3, "D5"), (93, 3, "C5"), (96, 6, "A4"),
            (102, 3, "C5"), (105, 3, "D5"), (108, 6, "E5"),
            (150, 3, "A5"), (153, 3, "G5"), (156, 3, "E5"), (159, 6, "C5"),
            (240, 6, "A4"), (246, 6, "E5"), (252, 6, "C5"), (258, 6, "A4")],
    big_booms=[99.0, 177.0, 279.0],
    small_booms=[333.0],
)

# ---------- 小工具 ----------
def _bg(seed, t, tint=(0.10, 0.20, 0.45), base=(0.010, 0.014, 0.032), nebula=0.5):
    low = dark_bg(seed, t, base=base, tint=tint, tint2=(0.16, 0.12, 0.38), nebula=nebula)
    low = blur_rgb(low, 0.8)
    return resize_rgb(low, W, H, ) if False else low

def _marker(cv, t, dur, *_):
    return ep_marker(cv, t, dur, EP_NO, TITLE)

def _stars(cv, t, n=260, seed=9):
    p, b, tw = starfield(n, seed)
    return draw_stars(cv, p, b, tw, t)

# ================= 场景 =================
def scene_cold_open(t, dur):
    canvas = np.zeros((H, W, 3), np.float32)
    low = dark_bg(0, t, base=(0.004, 0.006, 0.016), tint=(0.05, 0.08, 0.2), nebula=0.15)
    canvas += resize_rgb(low, W, H)
    # 打字机："AI 为什么会说话？"
    text = "AI 为什么会说话？"
    n = min(len(text), int(t / 0.45))
    shown = text[:n]
    spr = text_sprite(shown, "cn_light", 72, (225, 235, 255), tracking=10)
    comp_glow_text(canvas, spr, W // 2 - (len(text) - n) * 44, 500, alpha=0.96, gain=1.1,
                   halo=0.6, radius=10)
    # 光标
    if (t * 2.2) % 2 > 1 or n >= len(text):
        cursor(canvas, W // 2 + (n * 88) - (len(text) - n) * 88 + 40, 480, t, h=70)
    if t > dur - 4:
        a = fade_win(t - (dur - 4), 4, 1.2, 1.2)
        spr2 = text_sprite("它不是检索，不是复制——", "cn_light", 32, (165, 180, 215), tracking=8)
        comp_add(canvas, spr2, W // 2, 660, alpha=a)
        spr3 = text_sprite("它在做一件简单到不可思议的事", "cn_light", 32, (165, 180, 215), tracking=8)
        comp_add(canvas, spr3, W // 2, 715, alpha=a)
    return canvas

def scene_opening(t, dur):
    low = dark_bg(1, t, tint=(0.12, 0.22, 0.5), nebula=0.65)
    # token 方块从四周汇聚成环
    rng = np.random.default_rng(7)
    n = 26
    tokens = ["AI", "话", "模型", "Ġthe", "Tokens", "词", "下一", "▲", "GPT", "字", "▁", "网络",
              "概率", "文", "##ing", "本", "猜", "LLM", "训", "▁C", "脑", "元", "知识", "##ed",
              "习", "神"]
    goals = []
    for i in range(n):
        a = i / n * 2 * np.pi - np.pi / 2
        goals.append((W / 2 + np.cos(a) * 560, H / 2 + np.sin(a) * 320))
    k = ease_out(clamp01((t - 0.8) / 3.2))
    for i, tk in enumerate(tokens):
        gx, gy = goals[i]
        sx, sy = (W / 2) + (gx - W / 2) * 3.2, (H / 2) + (gy - H / 2) * 3.0
        x = sx + (gx - sx) * k
        y = sy + (gy - sy) * k
        col = palette_stops([(0, (0.4, 0.7, 1.0)), (0.5, (0.7, 0.55, 1.0)), (1, (0.45, 0.95, 0.85))], i / n)
        spr = token_block_sprite(tk, 76, col)
        comp_add(low, spr, x / 3, y / 3, alpha=k * 0.95, gain=1.0)
    low = blur_rgb(low, 0.7)
    canvas = resize_rgb(low, W, H)
    a1 = fade_win(t - 3.5, dur - 3.5, 2.0, 1.6)
    if a1 > 0.01:
        k2 = ease_out(clamp01((t - 3.5) / 2.5))
        spr = sprite_scale(text_sprite("大模型原理", "cn_light", 130, (242, 246, 255), tracking=44),
                           1.05 - 0.05 * k2)
        comp_glow_text(canvas, spr, W // 2, 420, alpha=a1, gain=1.15, halo=0.65, radius=13)
        spr2 = text_sprite("EP.01  一切从「猜下一个词」开始", "cn_light", 40, (190, 205, 240), tracking=12)
        comp_glow_text(canvas, spr2, W // 2, 585, alpha=a1 * 0.95, gain=1.0, halo=0.5, radius=8)
        spr3 = text_sprite("HOW LARGE LANGUAGE MODELS WORK", "lat_light", 22, (135, 150, 195), tracking=14)
        comp_add(canvas, spr3, W // 2, 655, alpha=a1 * 0.85)
    _marker(canvas, t, dur, EP_NO, TITLE)
    return canvas

def scene_chat(t, dur):
    low = dark_bg(2, t, tint=(0.10, 0.22, 0.48), nebula=0.4)
    low = blur_rgb(low, 0.8)
    canvas = resize_rgb(low, W, H)
    _stars(canvas, t, 180)
    q = "天空为什么是蓝色的？"
    a1 = fade_win(t, dur, 0.6, 0.6)
    chat_bubble(canvas, q, True, W // 2 + 150, 380, t_in=a1)
    # AI 打字回复
    ans = "因为瑞利散射：蓝光波长更短，被大气散射得更强。"
    n_char = int(clamp01((t - 1.6) / (dur - 2.4)) * len(ans))
    shown = ans[:n_char]
    chat_bubble(canvas, shown if shown else " ", False, W // 2 - 100, 580, t_in=a1)
    if 0 < n_char < len(ans):
        # 光标打字
        spr_t = text_sprite(shown, "cn_light", 27, (235, 240, 252), tracking=2)
        tw = min(760, spr_t.shape[1] + 90)
        cursor(canvas, W // 2 - 100 - tw / 2 + 62 + spr_t.shape[1], 580 - 8, t, h=36)
    if t > dur - 5:
        a2 = fade_win(t - (dur - 5), 5, 1.0, 1.0)
        spr = text_sprite("回答得又快又好——它是什么？", "cn_light", 30, (200, 215, 245), tracking=8)
        comp_glow_text(canvas, spr, W // 2, 810, alpha=a2, gain=1.0, halo=0.45, radius=7)
    _marker(canvas, t, dur, EP_NO, TITLE)
    return canvas

def scene_question(t, dur):
    low = dark_bg(3, t, tint=(0.10, 0.22, 0.48), nebula=0.4)
    low = blur_rgb(low, 0.8)
    canvas = resize_rgb(low, W, H)
    _stars(canvas, t, 160)
    a = fade_win(t, dur, 0.8, 0.8)
    # 放大最后一个字
    k = 1.0 + 0.5 * ease_out(clamp01(t / 3))
    spr = sprite_scale(text_sprite("色", "cn_light", 120, (235, 242, 255), tracking=0), k)
    comp_glow_text(canvas, spr, W // 2 - 500, 460, alpha=a * 0.95, gain=1.15, halo=0.7, radius=14)
    sprq = eq_sprite(r"\mathbf{?}", 60, (255, 210, 130))
    comp_glow_text(canvas, sprq, W // 2 - 130, 360 + np.sin(t * 1.4) * 10, alpha=a * 0.95,
                   gain=1.1, halo=0.6, radius=10)
    a2 = fade_win(t - 1.6, dur - 1.6, 1.4, 1.0)
    spr2 = text_sprite("每一个字，都是猜出来的", "cn_light", 52, (245, 248, 255), tracking=16)
    comp_glow_text(canvas, spr2, W // 2 + 130, 470 + np.sin(t * 0.9) * 6, alpha=a2 * 0.97,
                   gain=1.12, halo=0.62, radius=11)
    spr3 = text_sprite("P( 下一个字 | 前面的字 )", "cn_light", 26, (160, 180, 220), tracking=6)
    comp_add(canvas, spr3, W // 2 + 130, 575, alpha=a2 * 0.9)
    _marker(canvas, t, dur, EP_NO, TITLE)
    return canvas

def scene_core_demo(t, dur):
    low = dark_bg(4, t, tint=(0.10, 0.24, 0.5), nebula=0.4)
    low = blur_rgb(low, 0.8)
    canvas = resize_rgb(low, W, H)
    _stars(canvas, t, 140)
    a = fade_win(t, dur, 0.8, 0.8)
    # 输入 token 行
    toks = ["天空", "的", "颜色", "是"]
    token_row_static(canvas, toks, W // 2, 260, box=104, gap=20,
                     colors=[(0.45, 0.75, 1.0)] * 3 + [(1.0, 0.85, 0.45)],
                     alpha=a, highlight=[3] if t > 2 else None)
    spr_eq1 = text_sprite("P(", "lat_light", 40, (170, 190, 230), tracking=0)
    spr_eq2 = text_sprite("下一个字", "cn_light", 34, (235, 225, 180), tracking=2)
    spr_eq3 = text_sprite("| 前文的字 )", "cn_light", 32, (170, 190, 230), tracking=2)
    comp_add(canvas, spr_eq1, W // 2 - 230, 380, alpha=a * 0.9)
    comp_add(canvas, spr_eq2, W // 2 - 130, 380, alpha=a * 0.95)
    comp_add(canvas, spr_eq3, W // 2 + 60, 380, alpha=a * 0.9)
    # 概率条（真实 softmax）
    logits = [("蓝", 3.1), ("是", 1.35), ("很", 1.05), ("青", 0.15), ("不", -0.3)]
    T = 0.7
    probs = softmax([l for _, l in logits], T)
    items = [(lab, float(p), col) for (lab, _), p, col in
             zip(logits, probs, [(0.45, 0.75, 1.0), (0.55, 0.65, 1.0), (0.6, 0.55, 1.0),
                                 (0.65, 0.5, 1.0), (0.7, 0.45, 1.0)])]
    chosen = 0 if t > 12 else None
    # 采样扫描指针（t 6-12s 内滚动减速停在第一名）
    if 6 < t < 12:
        u = ease_out(clamp01((t - 6) / 6))
        sweep_y = 300 + u * (300 + 5 * 42 - 260)
        ln = Trails(LW, LH, 1.0); ln.buf[:] = 0
        ln.splat([280 / 3], [sweep_y / 3], (1.0, 0.95, 0.7), 1.6)
        canvas += resize_rgb(ln.buf, W, H)
    prob_bars(canvas, items, W // 2 + 60, 640, bar_w=640, bar_h=30, gap=18,
              t=t, reveal=clamp01((t - 2) / 2.5), chosen=chosen)
    if t > 13:
        # 选中 token 飞回句子
        k = ease_out(clamp01((t - 13) / 2.2))
        spr_b = token_block_sprite("蓝", 104, (1.0, 0.85, 0.45))
        x = W // 2 + 60 - 640 / 2 + 40
        y0, y1 = 640 - 2 * 48, 260
        comp_add(canvas, spr_b, x + (W // 2 + 3 * 124 + 62 - x) * k,
                 y0 + (y1 - y0) * k, alpha=1.0, gain=1.15)
    caption(canvas, t, dur, "模型给出的不是答案，是一个概率分布——再从里面抽一个",
            "真实的 softmax 数值，温度 T = 0.7", delay=1.0)
    _marker(canvas, t, dur, EP_NO, TITLE)
    return canvas

def scene_loop(t, dur):
    low = dark_bg(5, t, tint=(0.10, 0.22, 0.48), nebula=0.42)
    low = blur_rgb(low, 0.8)
    canvas = resize_rgb(low, W, H)
    _stars(canvas, t, 150)
    a = fade_win(t, dur, 0.8, 0.8)
    canvas, pos = generation_loop(canvas, t, W // 2, 520)
    a2 = fade_win(t - 1.5, dur - 1.5, 1.2, 1.0)
    spr = text_sprite("追加之后，再猜下一个——如此循环", "cn_light", 34, (225, 235, 255), tracking=8)
    comp_glow_text(canvas, spr, W // 2, 200, alpha=a2 * 0.95, gain=1.05, halo=0.5, radius=8)
    # 循环小字
    for i, s in enumerate(["你看到的每一个字", "都经历了这个循环"]):
        spr2 = text_sprite(s, "cn_light", 26, (165, 182, 220), tracking=6)
        comp_add(canvas, spr2, W // 2, 880 + i * 52, alpha=a2 * 0.9)
    _marker(canvas, t, dur, EP_NO, TITLE)
    return canvas

def scene_temperature(t, dur):
    low = dark_bg(6, t, tint=(0.12, 0.20, 0.46), nebula=0.4)
    low = blur_rgb(low, 0.8)
    canvas = resize_rgb(low, W, H)
    _stars(canvas, t, 140)
    a = fade_win(t, dur, 0.8, 0.8)
    logits = [3.1, 1.35, 1.05, 0.15, -0.3]
    labels = ["蓝", "是", "很", "青", "不"]
    temps = [0.2, 0.7, 1.5]
    names = ["严谨", "平衡", "发散"]
    cols = [(0.45, 0.9, 1.0), (0.5, 0.75, 1.0), (1.0, 0.6, 0.75)]
    # 温度滑块
    slider_x0, slider_x1 = W // 2 - 380, W // 2 + 380
    u = ease_io(clamp01((t - 1) / (dur - 3)))
    Tnow = 0.2 + u * 1.3
    poly_lr(canvas, [(slider_x0 / 3, 240 / 3), (slider_x1 / 3, 240 / 3)], (0.5, 0.6, 0.85), 0.5)
    tr = Trails(LW, LH, 1.0); tr.buf[:] = 0
    tr.splat([(slider_x0 + (slider_x1 - slider_x0) * (Tnow - 0.2) / 1.3) / 3], [240 / 3],
             (1.0, 0.85, 0.5), 2.4)
    canvas += resize_rgb(tr.buf, W, H) * 0.9
    sprT = eq_sprite(f"T = {Tnow:.1f}", 36, (255, 225, 170))
    comp_add(canvas, sprT, slider_x0 - 130, 240, alpha=a)
    # 三档小面板
    phase = clamp01(u * 3)
    for i, (T, nm, col) in enumerate(zip(temps, names, cols)):
        on = clamp01(phase - i)
        if on <= 0.02:
            continue
        probs = softmax(logits, T)
        items = [(lab, float(p), col) for lab, p in zip(labels, probs)]
        cx = W * (0.25 + i * 0.25)
        prob_bars(canvas, items, cx, 560, bar_w=300, bar_h=17, gap=10,
                  t=t, reveal=on)
        spr = text_sprite(f"T={T}" if T != 0.7 else "T=0.7 平衡", "lat_semi", 28,
                          tuple(int(c * 255) for c in col), tracking=2)
        comp_add(canvas, spr, cx, 420, alpha=a * on)
        sprn = text_sprite(nm, "cn_light", 30, (225, 232, 250), tracking=8)
        comp_add(canvas, sprn, cx, 470, alpha=a * on * 0.95)
    caption(canvas, t, dur, "温度调低——稳定可靠；温度调高——天马行空",
            "同一组分数，不同的抽取性格（真实的 exp(logit/T) 归一化）", delay=0.8)
    _marker(canvas, t, dur, EP_NO, TITLE)
    return canvas

def scene_greedy(t, dur):
    low = dark_bg(7, t, tint=(0.10, 0.20, 0.44), nebula=0.38)
    low = blur_rgb(low, 0.8)
    canvas = resize_rgb(low, W, H)
    a = fade_win(t, dur, 0.8, 0.8)
    # 上：贪心
    spr1 = text_sprite("贪心：永远挑最大的", "cn_light", 30, (200, 210, 235), tracking=6)
    comp_add(canvas, spr1, 330, 330, alpha=a)
    seq1 = ["蓝色", "蓝色", "蓝色", "蓝色"]
    token_row_static(canvas, seq1, 700, 430, box=86, gap=16,
                     colors=[(0.55, 0.55, 0.75)] * 4, alpha=a)
    # 下：采样
    spr2 = text_sprite("采样：按概率抽签", "cn_light", 30, (200, 210, 235), tracking=6)
    comp_add(canvas, spr2, 330, 600, alpha=a)
    seq2 = ["蔚蓝", "的", "深蓝", "天空"]
    token_row_static(canvas, seq2, 700, 700, box=86, gap=16,
                     colors=[(0.45, 0.8, 1.0), (0.5, 0.75, 1.0), (0.45, 0.8, 1.0), (1.0, 0.85, 0.45)],
                     alpha=a)
    a2 = fade_win(t - 2, dur - 2, 1.2, 1.0)
    spr3 = text_sprite("贪心可靠但死板，采样多样而鲜活", "cn_light", 34, (235, 240, 252), tracking=8)
    comp_glow_text(canvas, spr3, W // 2, 880, alpha=a2, gain=1.05, halo=0.5, radius=8)
    _marker(canvas, t, dur, EP_NO, TITLE)
    return canvas

def scene_params(t, dur):
    low = dark_bg(8, t, tint=(0.10, 0.22, 0.44), nebula=0.45)
    low = blur_rgb(low, 0.8)
    canvas = resize_rgb(low, W, H)
    # 参数数字雨（低分辨率，发光）
    rng = np.random.default_rng(12)
    tr = Trails(LW, LH, 0.86)
    cols_n = 46
    xs = rng.uniform(0, LW, cols_n)
    ys = (np.arange(cols_n) * 13.7 + t * rng.uniform(120, 260, cols_n)) % LH
    chars = [str(rng.integers(0, 10)) for _ in range(cols_n)]
    tr.splat(xs, ys, (0.4, 0.85, 0.75), 1.2)
    tr.splat(xs + 2, ys - 6, (0.4, 0.85, 0.75), 0.4)
    low = dark_bg(8, t, tint=(0.10, 0.24, 0.42), nebula=0.4) + tr.buf * 0.8
    low = blur_rgb(low, 0.8)
    canvas = resize_rgb(low, W, H)
    a = fade_win(t, dur, 1.0, 0.8)
    # 大数字滚动
    n_target = 70_000_000_000
    shown = int(n_target * ease_out(clamp01(t / 4)))
    spr = text_sprite(f"{shown:,}", "lat_light", 88, (240, 246, 255), tracking=4)
    comp_glow_text(canvas, spr, W // 2, 430, alpha=a * 0.97, gain=1.15, halo=0.65, radius=12)
    spr2 = text_sprite("个参数 —— 每一个都是可学习的「旋钮」", "cn_light", 32, (185, 200, 235), tracking=8)
    comp_glow_text(canvas, spr2, W // 2, 560, alpha=a * 0.95, gain=1.0, halo=0.5, radius=8)
    spr3 = text_sprite("训练就是反复微调这 700 亿个旋钮，直到猜得更准", "cn_light", 27, (165, 182, 220), tracking=5)
    comp_add(canvas, spr3, W // 2, 650, alpha=fade_win(t - 3, dur - 3, 1.2, 1.0) * 0.92)
    caption(canvas, t, dur, "猜得准不准，全看这 700 亿个旋钮的设置", "参数 = 模型学到的全部知识载体", delay=1.2)
    _marker(canvas, t, dur, EP_NO, TITLE)
    return canvas

def scene_layers(t, dur):
    low = dark_bg(9, t, tint=(0.11, 0.20, 0.46), nebula=0.42)
    low = blur_rgb(low, 0.8)
    canvas = resize_rgb(low, W, H)
    a = fade_win(t, dur, 0.8, 0.8)
    layer_stack(canvas, t, n_layers=6, cx=W // 2, cy=520)
    # 下方输入 token 行
    token_row_static(canvas, ["天空", "的", "颜色", "是"], W // 2, 810, box=78, gap=16,
                     alpha=a * 0.95)
    # 上方输出小分布
    probs = softmax([3.1, 1.35, 1.05, 0.15, -0.3], 0.7)
    prob_bars(canvas, [("蓝", float(probs[0]), (1.0, 0.85, 0.45)),
                       ("是", float(probs[1]), (0.55, 0.65, 1.0)),
                       ("很", float(probs[2]), (0.6, 0.55, 1.0))],
              W // 2 + 480, 400, bar_w=240, bar_h=14, gap=9, t=t, reveal=clamp01((t - 2) / 2))
    spr = text_sprite("输入 → 几十层变换 → 输出概率", "cn_light", 30, (210, 222, 248), tracking=8)
    comp_glow_text(canvas, spr, W // 2, 170, alpha=a * 0.95, gain=1.0, halo=0.5, radius=7)
    spr2 = text_sprite("每一层都在 refinement：从字面，到语法，到语义", "cn_light", 22, (160, 178, 215), tracking=4)
    comp_add(canvas, spr2, W // 2, 225, alpha=a * 0.85)
    _marker(canvas, t, dur, EP_NO, TITLE)
    return canvas

def scene_stages(t, dur):
    low = dark_bg(10, t, tint=(0.10, 0.20, 0.44), nebula=0.4)
    low = blur_rgb(low, 0.8)
    canvas = resize_rgb(low, W, H)
    a = fade_win(t, dur, 0.8, 0.8)
    # 左右分屏
    ln = Trails(LW, LH, 1.0); ln.buf[:] = 0
    ln.splat([LW / 2 / 3] * 60, np.linspace(160 / 3, 920 / 3, 60), (0.4, 0.5, 0.8), 0.4)
    canvas += resize_rgb(ln.buf, W, H) * 0.7
    spr1 = text_sprite("训练 · 读书做题", "cn_light", 38, (245, 240, 220), tracking=8)
    comp_glow_text(canvas, spr1, W // 4, 260, alpha=a, gain=1.05, halo=0.5, radius=8)
    spr2 = text_sprite("推理 · 参数冻结", "cn_light", 38, (220, 240, 255), tracking=8)
    comp_glow_text(canvas, spr2, W * 3 / 4, 260, alpha=a, gain=1.05, halo=0.5, radius=8)
    # 左：loss 曲线
    lc = Trails(LW, LH, 1.0); lc.buf[:] = 0
    loss_curve(lc, clamp01(t / (dur - 2)), x0=140, y0=780, w=520, h=300)
    canvas += resize_rgb(lc.buf, W, H) * 0.95
    sprl = text_sprite("错得多 → 调旋钮 → 错得更少", "cn_light", 24, (200, 190, 170), tracking=4)
    comp_add(canvas, sprl, W // 4, 830, alpha=a * 0.9)
    # 右：生成循环（小）
    generation_loop(canvas, t * 0.7, W * 3 / 4, 560, R=170,
                    stages=("输入", "概率", "采样", "输出"))
    sprr = text_sprite("旋钮不动，只管猜", "cn_light", 24, (180, 205, 230), tracking=4)
    comp_add(canvas, sprr, W * 3 / 4, 830, alpha=a * 0.9)
    _marker(canvas, t, dur, EP_NO, TITLE)
    return canvas

def scene_not_retrieval(t, dur):
    low = dark_bg(11, t, tint=(0.12, 0.18, 0.42), nebula=0.4)
    low = blur_rgb(low, 0.8)
    canvas = resize_rgb(low, W, H)
    a = fade_win(t, dur, 0.8, 0.8)
    # 左：书架（检索库）+ 红叉
    for shelf in range(3):
        y = 430 + shelf * 110
        poly_lr(canvas, [(160 / 3, y / 3), (860 / 3, y / 3)], (0.55, 0.6, 0.75), 0.7)
        for b in range(8):
            bx = 190 + b * 82 + (shelf % 2) * 20
            bh = 70 + (b * 13 + shelf * 29) % 30
            poly_lr(canvas, [(bx / 3, y / 3), (bx / 3, (y - bh) / 3)], (0.5, 0.6, 0.8), 0.5)
    # 红叉
    if t > dur * 0.35:
        k = ease_out(clamp01((t - dur * 0.35) / 1.2))
        cx0, cy0 = 510, 500
        for sgn in (-1, 1):
            poly_lr(canvas, np.stack([np.linspace(cx0 - 180 * k * sgn, cx0 + 180 * k * sgn, 40),
                                      np.linspace(cy0 - 150 * k, cy0 + 150 * k, 40)], 1),
                    (1.0, 0.35, 0.35), 1.4)
    spr1 = text_sprite("它不是检索库", "cn_light", 40, (240, 244, 255), tracking=10)
    comp_glow_text(canvas, spr1, 510, 300, alpha=a, gain=1.05, halo=0.5, radius=8)
    spr2 = text_sprite("没有句子仓库可以翻", "cn_light", 24, (255, 160, 160), tracking=5)
    comp_add(canvas, spr2, 510, 700, alpha=a * ease_out(clamp01((t - dur * 0.35) / 1.0)))
    # 右：参数点云（规律之海）
    point_cloud(canvas, t * 0.6, n=380, seed=21, spread=0.9, center=(LW * 0.72, LH * 0.45))
    spr3 = text_sprite("它是一片「规律」之海", "cn_light", 40, (240, 244, 255), tracking=10)
    comp_glow_text(canvas, spr3, W * 3 / 4, 300, alpha=a, gain=1.05, halo=0.5, radius=8)
    spr4 = text_sprite("700 亿个参数，编码的是语法、事实与概率", "cn_light", 24, (170, 190, 225), tracking=4)
    comp_add(canvas, spr4, W * 3 / 4, 700, alpha=a * 0.9)
    caption(canvas, t, dur, "所以它说得像人，却也可能「编」得像人——下一集我们还会回到这点",
            None, delay=1.5)
    _marker(canvas, t, dur, EP_NO, TITLE)
    return canvas

def scene_why_powerful(t, dur):
    low = dark_bg(12, t, tint=(0.10, 0.22, 0.48), nebula=0.42)
    low = blur_rgb(low, 0.8)
    canvas = resize_rgb(low, W, H)
    _stars(canvas, t, 150)
    a = fade_win(t, dur, 0.8, 0.8)
    spr0 = text_sprite("一个简单的目标，为什么这么强？", "cn_light", 40, (242, 246, 255), tracking=10)
    comp_glow_text(canvas, spr0, W // 2, 210, alpha=a, gain=1.1, halo=0.6, radius=9)
    examples = [
        ("语法", "天空的颜色是____", "名词短语", "读得多了，语感自然准", (0.45, 0.8, 1.0)),
        ("事实", "光在真空中的速度是每秒____", "30 万公里", "想猜对，就得记住事实", (0.7, 0.55, 1.0)),
        ("推理", "A 比 B 高，B 比 C 高，那么 A 和 C 比？", "A 更高", "想猜对，就得学会推理", (1.0, 0.8, 0.45)),
    ]
    for i, (tag, q, ans, note, col) in enumerate(examples):
        t0 = 1.5 + i * 7
        g = ease_out(clamp01((t - t0) / 1.6))
        if g <= 0.01:
            continue
        y = 340 + i * 160
        sprt = text_sprite(tag, "cn_light", 30, tuple(int(c * 255) for c in col), tracking=6)
        comp_add(canvas, sprt, 260, y, alpha=a * g)
        sprq = text_sprite(q, "cn_light", 30, (225, 232, 248), tracking=3)
        comp_add(canvas, sprq, 480, y, alpha=a * g)
        if t > t0 + 2.5:
            ga = fade_win(t - t0 - 2.5, 3, 0.8, 2.0)
            spra = text_sprite("→ " + ans, "cn_light", 32, tuple(int(c * 255) for c in np.array(col) * 0.5 + 127),
                               tracking=3)
            comp_glow_text(canvas, spra, 1010, y + 46, alpha=a * ga, gain=1.1, halo=0.5, radius=7)
        sprn = text_sprite(note, "cn_light", 20, (150, 165, 200), tracking=3)
        comp_add(canvas, sprn, 480, y + 46, alpha=a * g * 0.85)
    caption(canvas, t, dur, "为了把「下一个词」猜准，理解与推理是不得不长出来的能力",
            None, delay=2.0)
    _marker(canvas, t, dur, EP_NO, TITLE)
    return canvas

def scene_limits(t, dur):
    low = dark_bg(13, t, tint=(0.14, 0.14, 0.38), nebula=0.5)
    low = blur_rgb(low, 0.8)
    canvas = resize_rgb(low, W, H)
    _stars(canvas, t, 170)
    a = fade_win(t, dur, 1.0, 1.0)
    qs = [("它会一本正经地错吗？", (1.0, 0.6, 0.55)),
          ("它记得住昨天吗？", (0.55, 0.8, 1.0)),
          ("它真的「懂」了吗？", (0.7, 0.55, 1.0))]
    for i, (q, col) in enumerate(qs):
        t0 = 0.8 + i * 2.2
        g = ease_out(clamp01((t - t0) / 1.4))
        if g <= 0.01:
            continue
        y = 360 + i * 150
        k = 1.0 + 0.06 * np.sin(t * 1.2 + i)
        sprq = sprite_scale(text_sprite("？", "dengl", 110, tuple(int(c * 255) for c in col), tracking=0), k)
        comp_glow_text(canvas, sprq, W // 2 - 480, y + np.sin(t + i) * 8, alpha=a * g * 0.9,
                       gain=1.1, halo=0.6, radius=10)
        spr = text_sprite(q, "cn_light", 42, (235, 240, 252), tracking=10)
        comp_glow_text(canvas, spr, W // 2 + 80, y, alpha=a * g, gain=1.08, halo=0.55, radius=9)
    spr = text_sprite("这些代价与边界，就是这个系列的下半程", "cn_light", 26, (165, 182, 220), tracking=6)
    comp_add(canvas, spr, W // 2, 880, alpha=fade_win(t - 4, dur - 4, 1.2, 1.0) * 0.9)
    _marker(canvas, t, dur, EP_NO, TITLE)
    return canvas

def scene_knowledge_card(t, dur):
    low = dark_bg(14, t, tint=(0.10, 0.20, 0.44), nebula=0.45)
    low = blur_rgb(low, 0.8)
    canvas = resize_rgb(low, W, H)
    a = fade_win(t, dur, 0.8, 0.8)
    # 卡片底
    im = Image.new("L", (W, H), 0)
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([W // 2 - 560, 170, W // 2 + 560, 900], radius=28, outline=255, width=2)
    arr = np.asarray(im, np.float32) / 255 * a
    sm = blur_f(resize_f(arr, LW, LH), 1.6)
    canvas += resize_rgb(np.stack([sm * 0.45, sm * 0.55, sm * 0.95], -1), W, H) * 0.9
    canvas += arr[..., None] * np.array([0.3, 0.4, 0.8]) * 0.22
    sprt = text_sprite("本集知识卡", "cn_light", 40, (240, 244, 255), tracking=12)
    comp_glow_text(canvas, sprt, W // 2, 240, alpha=a * 0.97, gain=1.08, halo=0.55, radius=8)
    points = [
        ("本质", "大模型 = 超大规模的「猜下一个词」机器"),
        ("温度", "同一组分数，T 低则严谨，T 高则发散"),
        ("参数", "700 亿个旋钮，决定猜得准不准"),
        ("边界", "它不检索、会出错——规律不等于事实"),
    ]
    for i, (tag, txt) in enumerate(points):
        t0 = 1.0 + i * 2.2
        g = ease_out(clamp01((t - t0) / 1.2))
        if g <= 0.01:
            continue
        y = 360 + i * 125
        sprn = token_block_sprite(f"{i+1}", 64, (0.5, 0.75, 1.0))
        comp_add(canvas, sprn, W // 2 - 440, y, alpha=a * g)
        sprt2 = text_sprite(tag, "cn_light", 28, (255, 220, 150), tracking=6)
        comp_add(canvas, sprt2, W // 2 - 330, y, alpha=a * g)
        sprx = text_sprite(txt, "cn_light", 30, (228, 234, 250), tracking=3)
        comp_add(canvas, sprx, W // 2 - 210, y, alpha=a * g)
    _marker(canvas, t, dur, EP_NO, TITLE)
    return canvas

def scene_preview(t, dur):
    low = dark_bg(15, t, tint=(0.10, 0.20, 0.46), nebula=0.45)
    low = blur_rgb(low, 0.8)
    canvas = resize_rgb(low, W, H)
    a = fade_win(t, dur, 0.5, 0.5)
    spr = text_sprite("下集 · Token：AI 眼中的文字", "cn_light", 46, (242, 246, 255), tracking=12)
    comp_glow_text(canvas, spr, W // 2, 300, alpha=a * 0.97, gain=1.1, halo=0.6, radius=10)
    # 切词预览动画
    sent = "大模型把文字切成小块"
    pieces = ["大", "模型", "把", "文字", "切", "成", "小", "块"]
    n = min(len(pieces), int(clamp01(t / (dur * 0.6)) * len(pieces) + 0.5))
    toks = []
    x = 0
    for p in pieces[:max(n, 0)]:
        toks.append(p)
    if toks:
        token_row_static(canvas, toks, W // 2, 560, box=92, gap=14,
                         colors=[(0.45, 0.8, 1.0), (0.7, 0.55, 1.0)] * 4, alpha=a)
    spr2 = text_sprite("同一个句子，AI 读到的可能是这样", "cn_light", 26, (170, 186, 222), tracking=5)
    comp_add(canvas, spr2, W // 2, 680, alpha=a * 0.9)
    return canvas

def scene_endcard(t, dur):
    canvas = np.zeros((H, W, 3), np.float32)
    low = dark_bg(16, t, base=(0.004, 0.006, 0.016), tint=(0.08, 0.10, 0.26), nebula=0.5)
    canvas += resize_rgb(low, W, H) * 0.85
    a = fade_win(t - 0.4, dur - 0.4, 1.8, 2.4)
    spr = text_sprite("大模型原理 · EP.01", "cn_light", 44, (240, 244, 255), tracking=14)
    comp_glow_text(canvas, spr, W // 2, 430, alpha=a * 0.97, gain=1.1, halo=0.6, radius=10)
    spr2 = text_sprite("下一集：Token —— AI 眼中的文字", "cn_light", 27, (185, 198, 235), tracking=8)
    comp_add(canvas, spr2, W // 2, 545, alpha=a * 0.92)
    spr3 = text_sprite("QUANTUM OF TOKENS — HOW LLMS WORK", "lat_light", 19, (130, 145, 190), tracking=10)
    comp_add(canvas, spr3, W // 2, 610, alpha=a * 0.8)
    g2 = fade_win(t - 5, dur - 5, 1.5, 2.0)
    if g2 > 0.01:
        spr4 = text_sprite("画面 · 音乐 · 剪辑 —— 全程序化生成 | 关注，看下一集", "cn_light", 20,
                           (135, 148, 182), tracking=5)
        comp_add(canvas, spr4, W // 2, 950, alpha=g2 * 0.88)
    return canvas
