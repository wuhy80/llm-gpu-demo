# -*- coding: utf-8 -*-
"""tcommon —— common.py 的 torch 移植（API 完全同名，张量运行在 DEVICE 上）。

移植原则（与 CPU 版帧级对齐）：
  1. 随机数（噪声网格/星场/胶片颗粒/抖动）全部先走真 numpy 的 rng 再转 tensor——
     与 common.py 用同一种子同一条流，画面元素位置一致，可做严格 PSNR 校验。
  2. 文字/公式精灵仍用 PIL/matplotlib 栅格化（CPU，带缓存，成本可忽略），结果转 tensor。
  3. 缩放用 F.interpolate(bilinear, antialias=True)——antialias 模式与 PIL 的
     BILINEAR 重采样同源；高斯模糊用与 scipy gaussian_filter 同核
     （truncate=4 → kernel radius = int(4σ+0.5)）的可分离卷积 + replicate 边界。
"""
import os

import numpy as _np
import torch
import torch.nn.functional as F
from PIL import Image, ImageDraw, ImageFont

import tnp

W, H = 1920, 1080
LW, LH = 640, 360
FPS = 30

DEVICE = "cpu"

def set_device(d):
    global DEVICE
    DEVICE = d
    tnp.set_device(d)
    # 清掉所有设备相关缓存（精灵/噪声/暗角），下次访问时在新设备上重建
    _fc.clear(); _spr_cache.clear()
    NOISE.clear()
    for i in range(4):
        NOISE[i] = Noise2D(seed=i)
    globals()["VIGNETTE"] = None
    globals()["_yy"] = None
    globals()["XX"] = None
    globals()["YY"] = None
    GRAIN[:] = [None] * 12


# ---------------- 字体（优先同目录 fonts/，便于打包上云） ----------------
_FONT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts")
FONTS = {
    "cn_light": "msyhl.ttc",
    "cn":       "msyh.ttc",
    "cn_bold":  "msyhbd.ttc",
    "hei":      "simhei.ttf",
    "dengl":    "Dengl.ttf",
    "lat_light": "segoeuil.ttf",
    "lat_semi": "segoeuisl.ttf",
}

def _font_path(basename):
    local = os.path.join(_FONT_DIR, basename)
    if os.path.exists(local):
        return local
    win = os.path.join("C:/Windows/Fonts", basename)
    if os.path.exists(win):
        return win
    raise FileNotFoundError(f"字体缺失: {basename}（放入 {_FONT_DIR}）")

_fc = {}
def font(key, size):
    k = (key, int(size))
    if k not in _fc:
        _fc[k] = ImageFont.truetype(_font_path(FONTS[key]), int(size))
    return _fc[k]


# ---------------- 文字精灵（PIL 栅格化，输出 tensor RGBA 0..1） ----------------
_spr_cache = {}

def _to_dev(a):
    return torch.from_numpy(_np.ascontiguousarray(a)).to(DEVICE)

def text_sprite(text, key="cn_light", size=48, color=(255, 255, 255), tracking=0.0):
    ck = (text, key, int(size), color, float(tracking))
    if ck in _spr_cache:
        return _spr_cache[ck]
    f = font(key, size)
    tracking = tracking * size / 48.0
    widths = [f.getlength(c) for c in text]
    total = int(sum(widths) + tracking * (len(text) - 1)) + 8
    asc, desc = f.getmetrics()
    hgt = asc + desc + 8
    im = Image.new("L", (max(total, 1), hgt), 0)
    d = ImageDraw.Draw(im)
    x = 4.0
    for c, w in zip(text, widths):
        d.text((x, 4), c, font=f, fill=255)
        x += w + tracking
    a = _np.asarray(im, _np.float32) / 255.0
    spr = torch.zeros((a.shape[0], a.shape[1], 4), dtype=torch.float32, device=DEVICE)
    spr[..., 0] = color[0] / 255.0
    spr[..., 1] = color[1] / 255.0
    spr[..., 2] = color[2] / 255.0
    spr[..., 3] = torch.from_numpy(a).to(DEVICE)
    _spr_cache[ck] = spr
    return spr


# ---------------- 公式精灵（matplotlib mathtext） ----------------
def eq_sprite(latex, fontsize=40, color=(255, 255, 255), dpi=260):
    ck = ("eq", latex, fontsize, color)
    if ck in _spr_cache:
        return _spr_cache[ck]
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.figure as mfig
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    fig = mfig.Figure(figsize=(9, 3), dpi=dpi)
    FigureCanvasAgg(fig)
    fig.patch.set_alpha(0)
    fig.text(0.5, 0.5, f"${latex}$", fontsize=fontsize, ha="center", va="center", color="black")
    fig.canvas.draw()
    buf = _np.asarray(fig.canvas.buffer_rgba()).copy()
    a = buf[..., 3]
    ys, xs = _np.where(a > 3)
    if len(ys) == 0:
        spr = torch.zeros((4, 4, 4), dtype=torch.float32, device=DEVICE)
    else:
        buf = buf[ys.min():ys.max() + 1, xs.min():xs.max() + 1].astype(_np.float32) / 255.0
        spr = torch.zeros(buf.shape[:2] + (4,), dtype=torch.float32, device=DEVICE)
        spr[..., 0] = color[0] / 255.0
        spr[..., 1] = color[1] / 255.0
        spr[..., 2] = color[2] / 255.0
        spr[..., 3] = torch.from_numpy(buf[..., 3]).to(DEVICE)
    _spr_cache[ck] = spr
    return spr


# ---------------- 图像基础 ----------------
def to_u8(arr):
    if isinstance(arr, torch.Tensor):
        arr = arr.detach().cpu().numpy()
    return (_np.clip(arr, 0, 1) * 255).astype(_np.uint8)

def _interp2d(t, w, h):
    """(h0,w0) 或 (h0,w0,C) -> bilinear 到 (h,w) / (h,w,C)，对齐 PIL BILINEAR（antialias）"""
    if t.dim() == 2:
        return F.interpolate(t[None, None].float(), size=(h, w), mode="bilinear",
                             align_corners=False, antialias=True)
    x = t.permute(2, 0, 1)[None].float()   # (1,C,h,w)
    return F.interpolate(x, size=(h, w), mode="bilinear",
                         align_corners=False, antialias=True)

def resize_f(arr, w, h):
    return _interp2d(arr, w, h)[0, 0]

def _gauss_kernel1d(sigma):
    import math
    radius = int(4.0 * sigma + 0.5)   # 与 scipy gaussian_filter 默认 truncate=4 一致
    xs = torch.arange(-radius, radius + 1, dtype=torch.float32, device=DEVICE)
    k = torch.exp(-(xs ** 2) / (2.0 * sigma * sigma))
    return (k / k.sum())[None, None, :], radius

def blur_f(arr, radius):
    sigma = max(radius, 0.3)
    k, r = _gauss_kernel1d(sigma)
    kh = k.reshape(1, 1, 1, -1)
    kv = k.reshape(1, 1, -1, 1)
    x = arr[None, None].float()
    x = F.pad(x, (r, r, 0, 0), mode="replicate")
    x = F.conv2d(x, kh)
    x = F.pad(x, (0, 0, r, r), mode="replicate")
    x = F.conv2d(x, kv)
    return x[0, 0]

def _blur_batch(x3, radius):
    """x3: (h,w,3) -> 深度可分离高斯模糊（每通道独立，等价 scipy 逐通道 gaussian_filter）"""
    sigma = max(radius, 0.3)
    k, r = _gauss_kernel1d(sigma)
    x = x3.permute(2, 0, 1)[None].float()      # (1,3,h,w)
    kh = k.expand(3, 1, -1, -1)                # (3,1,1,K) depthwise
    kv = kh.transpose(2, 3)                    # (3,1,K,1)
    x = F.pad(x, (r, r, 0, 0), mode="replicate")
    x = F.conv2d(x, kh, groups=3)
    x = F.pad(x, (0, 0, r, r), mode="replicate")
    x = F.conv2d(x, kv, groups=3)
    return x[0].permute(1, 2, 0)

def blur_rgb(arr, radius):
    return _blur_batch(arr, radius)

def resize_rgb(arr, w, h):
    return _interp2d(arr, w, h)[0].permute(1, 2, 0)

def bloom(frame, thr=0.55, strength=0.75, radius=12):
    bright = (frame - thr).clamp(min=0)
    small = resize_rgb(bright, W // 4, H // 4)
    small = blur_rgb(small, radius)
    glow = resize_rgb(small, W, H)
    return frame + glow * strength

def streak(frame, thr=0.8, strength=0.8):
    bright = (frame - thr).clamp(min=0)
    small = resize_rgb(bright, W // 4, H // 4)
    # 与原实现一致：先高斯模糊(σ=2)再水平 uniform(size=19)
    k = torch.full((1, 1, 1, 19), 1.0 / 19.0, device=DEVICE)
    b = _blur_batch(small, 2.0).permute(2, 0, 1)[None].float()   # (1,3,h,w)
    b = F.pad(b, (9, 9, 0, 0), mode="replicate")
    b = F.conv2d(b, k.expand(3, 1, -1, -1), groups=3)
    glow = resize_rgb(b[0].permute(1, 2, 0), W, H)
    tint = torch.tensor([1.0, 0.95, 0.85], dtype=torch.float32, device=DEVICE)
    return frame + glow * strength * tint


# ---------------- 合成 ----------------
def comp_add(canvas, spr, cx, cy, alpha=1.0, gain=1.0):
    Hc, Wc = canvas.shape[:2]
    h, w = spr.shape[:2]
    x0 = int(round(float(cx - w / 2))); y0 = int(round(float(cy - h / 2)))
    x1, y1 = x0 + w, y0 + h
    sx0, sy0 = max(0, -x0), max(0, -y0)
    x0, y0 = max(0, x0), max(0, y0)
    x1, y1 = min(Wc, x1), min(Hc, y1)
    if x1 <= x0 or y1 <= y0:
        return canvas
    s = spr[sy0:sy0 + (y1 - y0), sx0:sx0 + (x1 - x0), :3] * \
        (spr[sy0:sy0 + (y1 - y0), sx0:sx0 + (x1 - x0), 3:4] * alpha * gain)
    canvas[y0:y1, x0:x1] += s
    return canvas

def comp_glow_text(canvas, spr, cx, cy, alpha=1.0, gain=1.0, halo=0.55, radius=8):
    if halo > 0:
        a = spr[..., 3:4]
        rgb = spr[..., :3]
        pad = 4 * radius
        big = torch.zeros((spr.shape[0] + pad, spr.shape[1] + pad, 3), dtype=torch.float32, device=DEVICE)
        aa = torch.zeros((spr.shape[0] + pad, spr.shape[1] + pad, 1), dtype=torch.float32, device=DEVICE)
        r = radius
        big[2 * r:2 * r + spr.shape[0], 2 * r:2 * r + spr.shape[1]] = rgb
        aa[2 * r:2 * r + spr.shape[0], 2 * r:2 * r + spr.shape[1]] = a
        halo_arr = _blur_batch(big * aa, radius)
        ones = torch.ones(halo_arr.shape[:2] + (1,), dtype=torch.float32, device=DEVICE)
        spr2 = torch.cat([halo_arr, ones], dim=-1)
        comp_add(canvas, spr2, cx, cy, alpha, gain * halo)
    comp_add(canvas, spr, cx, cy, alpha, gain)
    return canvas

def sprite_scale(spr, factor):
    if abs(factor - 1.0) < 1e-3:
        return spr
    h, w = spr.shape[:2]
    nw, nh = max(2, int(w * factor)), max(2, int(h * factor))
    x = spr.permute(2, 0, 1)[:, None].float()
    out = F.interpolate(x, size=(nh, nw), mode="bilinear",
                        align_corners=False, antialias=True)[:, 0].permute(1, 2, 0)
    return out


# ---------------- 噪声场（网格用 numpy rng 初始化，与 CPU 版逐值一致） ----------------
class Noise2D:
    def __init__(self, seed=0):
        r = _np.random.default_rng(seed)
        self.grids = {res: torch.from_numpy(r.random((res, res)).astype(_np.float32)).to(DEVICE)
                      for res in (32, 64, 128, 256)}

    @staticmethod
    def _sample(g, u, v):
        res = g.shape[0]
        u = torch.remainder(u, res); v = torch.remainder(v, res)
        x0 = u.floor().to(torch.int32) % res
        y0 = v.floor().to(torch.int32) % res
        x1 = (x0 + 1) % res; y1 = (y0 + 1) % res
        fx = u - u.floor(); fy = v - v.floor()
        fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy)
        a = g[y0, x0]; b = g[y0, x1]; c = g[y1, x0]; d = g[y1, x1]
        return (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy

    def fbm(self, x, y, t=0.0, base=3.0, octaves=4, speed=0.05, rough=0.55):
        out = torch.zeros_like(x)
        amp, tot = 1.0, 0.0
        for o in range(octaves):
            res = 32 * (2 ** o)
            sc = base * (2 ** o)
            u = (x * sc + t * speed * (o + 1) * 0.4) % 1.0 * res
            v = (y * sc + t * speed * (o + 1) * 0.3 + o * 7.31) % 1.0 * res
            out += amp * self._sample(self.grids[res], u, v)
            tot += amp
            amp *= rough
        return out / tot

NOISE = {i: Noise2D(seed=i) for i in range(4)}

def uv_grid(w=LW, h=LH):
    xs = torch.linspace(0, 1, w, device=DEVICE)
    ys = torch.linspace(0, 1, h, device=DEVICE)
    return torch.meshgrid(xs, ys, indexing="xy")


# ---------------- 粒子轨迹缓冲 ----------------
class Trails:
    def __init__(self, w=LW, h=LH, decay=0.90):
        self.w, self.h = w, h
        self.buf = torch.zeros((h, w, 3), dtype=torch.float32, device=DEVICE)
        self.decay = decay

    def splat(self, xs, ys, color, inten=1.0):
        xs = tnp.asarray(xs, torch.float32); ys = tnp.asarray(ys, torch.float32)
        n = len(xs)
        if n == 0:
            return
        xi = xs.to(torch.int64).clamp(0, self.w - 2)
        yi = ys.to(torch.int64).clamp(0, self.h - 2)
        col = tnp.asarray(color, torch.float32)
        inten = tnp.asarray(inten, torch.float32)
        if col.dim() == 1:
            c = col[None, :] * inten[:, None] if inten.dim() else col * inten
        else:
            c = col * (inten[:, None] if inten.dim() else inten)
        for dy, dx, wgt in ((0, 0, 1.0), (0, 1, 0.45), (1, 0, 0.45), (1, 1, 0.2)):
            idx = (yi + dy, xi + dx)
            self.buf.index_put_(idx, (c * wgt), accumulate=True)

    def step(self, decay=None):
        self.buf *= (self.decay if decay is None else decay)

    def clear(self):
        self.buf.zero_()


# ---------------- 3D 投影 ----------------
def proj3(pts, rx=0.55, rz=0.0, f=1000.0, cz=3.2, cx=None, cy=None, scale=1.0):
    if cx is None: cx = W / 2
    if cy is None: cy = H / 2
    pts = tnp.asarray(pts, torch.float32)
    rx = torch.as_tensor(rx, dtype=torch.float32, device=DEVICE)
    rz = torch.as_tensor(rz, dtype=torch.float32, device=DEVICE)
    ct, st = torch.cos(rx), torch.sin(rx)
    y = pts[:, 1] * ct - pts[:, 2] * st
    z = pts[:, 1] * st + pts[:, 2] * ct
    cr, sr = torch.cos(rz), torch.sin(rz)
    x2 = pts[:, 0] * cr - y * sr
    y2 = pts[:, 0] * sr + y * cr
    s = f / (z + cz)
    sx = cx + x2 * s * scale
    sy = cy - y2 * s * scale
    return sx, sy, z

def rot2(x, y, ang):
    ang = torch.as_tensor(ang, dtype=torch.float32, device=DEVICE)
    c, s = torch.cos(ang), torch.sin(ang)
    return x * c - y * s, x * s + y * c


# ---------------- 缓动（接受标量或张量，返回同型） ----------------
def ease_io(t):
    # python 标量走 float64（对齐 numpy 行为）；张量走 fp32
    if isinstance(t, (int, float)):
        t = min(max(t, 0.0), 1.0)
        return t * t * (3 - 2 * t)
    t = torch.clamp(torch.as_tensor(t, dtype=torch.float32, device=DEVICE), 0, 1)
    return t * t * (3 - 2 * t)

def ease_out(t):
    if isinstance(t, (int, float)):
        t = min(max(t, 0.0), 1.0)
        return 1 - (1 - t) ** 3
    t = torch.clamp(torch.as_tensor(t, dtype=torch.float32, device=DEVICE), 0, 1)
    return 1 - (1 - t) ** 3

def clamp01(x):
    if isinstance(x, (int, float)):
        return min(max(float(x), 0.0), 1.0)
    return torch.clamp(torch.as_tensor(x, dtype=torch.float32, device=DEVICE), 0.0, 1.0)

def fade_win(t, dur, fin=0.6, fout=0.6):
    return clamp01(min(t / fin, (dur - t) / fout)) if dur > 0 else clamp01(0.0)


# ---------------- 全局后处理素材（惰性建在当前 DEVICE） ----------------
VIGNETTE = None
_yy = None
XX = None
YY = None
GRAIN = [None] * 12

def _ensure_grid():
    global VIGNETTE, _yy, XX, YY
    if VIGNETTE is not None:
        return
    yy, xx = torch.meshgrid(torch.arange(H, device=DEVICE, dtype=torch.float32),
                            torch.arange(W, device=DEVICE, dtype=torch.float32), indexing="ij")
    r = torch.sqrt(((xx - W / 2) / (W / 2)) ** 2 + ((yy - H / 2) / (H / 2)) ** 2)
    VIGNETTE = (1.0 - 0.42 * (r - 0.35).clamp(min=0) ** 1.8)[..., None].contiguous()
    _yy, XX, YY = yy, xx, xx

def _grid_lazy():
    _ensure_grid()
    return VIGNETTE, XX, YY

def grain_frame(i):
    if GRAIN[i % 12] is None:
        rng = _np.random.default_rng(i)
        g = rng.normal(0, 1, (H // 2, W // 2)).astype(_np.float32)
        GRAIN[i % 12] = torch.from_numpy(g).to(DEVICE)
    return GRAIN[i % 12]


# ---------------- 低分辨率背景生成 ----------------
def dark_bg(seed=0, t=0.0, base=(0.012, 0.016, 0.035), tint=(0.10, 0.16, 0.42),
            tint2=(0.30, 0.10, 0.38), nebula=0.55, warp=0.0):
    x, y = uv_grid()
    n1 = NOISE[0].fbm(x, y, t, base=2.5, octaves=4, speed=0.03)
    n2 = NOISE[1].fbm(x + 0.33, y - 0.21, t * 0.7, base=4.0, octaves=3, speed=0.05)
    neb = ((n1 * 1.35 - 0.28).clamp(0, 1)) ** 1.7
    col = torch.empty((LH, LW, 3), dtype=torch.float32, device=DEVICE)
    for c in range(3):
        col[..., c] = base[c] + neb * (tint[c] * nebula) + (n2 - 0.45).clamp(0, 1) * tint2[c] * nebula * 0.7
    r2 = ((x - 0.5) ** 2 + (y - 0.5) ** 2) * 2.6
    col *= (1.0 - 0.35 * r2)[..., None]
    return col

def starfield(n=340, seed=7):
    rng = _np.random.default_rng(seed)
    p = torch.from_numpy(_np.stack([rng.uniform(0, W, n), rng.uniform(0, H, n)], 1).astype(_np.float32)).to(DEVICE)
    b = torch.from_numpy((rng.random(n) ** 2.6 * 0.5 + 0.03).astype(_np.float32)).to(DEVICE)
    tw = torch.from_numpy(rng.uniform(0, 6.28, n).astype(_np.float32)).to(DEVICE)
    return p, b, tw

def draw_stars(canvas, p, b, tw, t, drift=(6.0, 2.0)):
    xs = (p[:, 0] + t * drift[0]) % W
    ys = (p[:, 1] + t * drift[1]) % H
    inten = b * (0.7 + 0.3 * torch.sin(t * 2.0 + tw))
    tr = Trails(W, H, 1.0)
    tr.buf.zero_()
    tr.splat(xs, ys, (1.0, 1.0, 1.0), inten)
    canvas += tr.buf * 0.55
    return canvas


# ---------------- 色彩工具 ----------------
def palette_stops(stops, t):
    ps = torch.tensor([s[0] for s in stops], dtype=torch.float32, device=DEVICE)
    cs = torch.tensor([s[1] for s in stops], dtype=torch.float32, device=DEVICE)
    t_in = torch.as_tensor(t, dtype=torch.float32, device=DEVICE)
    scalar = t_in.dim() == 0
    shape = t_in.shape
    tt = torch.clamp(t_in, 0, 1).flatten()
    out = torch.empty((tt.numel(), 3), dtype=torch.float32, device=DEVICE)
    for c in range(3):
        out[:, c] = torch.from_numpy(_np.interp(tt.detach().cpu().numpy(),
                                                ps.detach().cpu().numpy(),
                                                cs[:, c].detach().cpu().numpy())).to(DEVICE)
    if scalar:
        return out[0]
    return out.reshape(*shape, 3)
