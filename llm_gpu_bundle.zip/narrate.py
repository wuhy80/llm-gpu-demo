# -*- coding: utf-8 -*-
"""解说词 TTS + 混音流水线。
用法: python narrate.py ep01 [engine]
  engine: f5（默认，若有 ref_voice.wav 且已装 f5-tts）| edge | chat（占位）
读取 narration_<ep>.json → 逐句 TTS → 按时间轴拼装解说轨
→ 与 soundtrack_<ep>.wav 混音（解说出现时背景乐自动闪避）
→ 与 out/<ep>.mp4 合成 out/<ep>_narrated.mp4

F5-TTS 音色克隆：工作目录放 ref_voice.wav（5-15s 干净人声）即可；
ref_text.txt（参考音频对应的文字）可选，能提升克隆稳定性。
"""
import asyncio, json, os, subprocess, sys, wave
import numpy as np

SR = 44100

def _sentence_path(workdir, i):
    """f5 优先 .wav，edge 用 .mp3——挑已存在/将生成的扩展名"""
    if os.path.exists(os.path.join(workdir, f"line_{i:02d}.wav")):
        return os.path.join(workdir, f"line_{i:02d}.wav")
    return os.path.join(workdir, f"line_{i:02d}.mp3")

def tts_lines(ep, cfg, workdir):
    os.makedirs(workdir, exist_ok=True)
    import edge_tts
    async def run():
        for i, line in enumerate(cfg["lines"]):
            out = os.path.join(workdir, f"line_{i:02d}.mp3")
            if os.path.exists(out) and os.path.getsize(out) > 1000:
                continue
            tts = edge_tts.Communicate(line["text"], cfg["voice"], rate=cfg.get("rate", "+4%"))
            await tts.save(out)
            print(f"  tts line {i:02d} @ {line['t']}s", flush=True)
    asyncio.run(run())

def pick_engine(ep, engine=None):
    """引擎选择：显式指定 > ref_voice.wav 存在且 f5 可用 > edge 兜底"""
    cfg = json.load(open(f"narration_{ep}.json", encoding="utf-8"))
    if engine is None:
        engine = "f5" if (os.path.exists("ref_voice.wav") and _f5_ok()) else "edge"
    return cfg, engine

def _f5_ok():
    try:
        import f5_tts  # noqa: F401
        return True
    except Exception:
        return False

def tts_dispatch(ep, cfg, workdir, engine):
    if engine == "f5":
        from tts_f5 import tts_lines_f5
        if not os.path.exists("ref_voice.wav"):
            print("  [f5] 缺 ref_voice.wav，回退 edge-tts")
            return tts_lines(ep, cfg, workdir)
        tts_lines_f5(cfg, workdir, "ref_voice.wav")
    else:
        tts_lines(ep, cfg, workdir)

def mp3_to_f32(mp3_path):
    raw = subprocess.run(
        ["ffmpeg", "-loglevel", "error", "-i", mp3_path, "-f", "s16le",
         "-ar", str(SR), "-ac", "2", "-"],
        capture_output=True, check=True).stdout
    x = np.frombuffer(raw, np.int16).astype(np.float32) / 32767.0
    return x.reshape(-1, 2)

def main(ep, engine=None):
    cfg, engine = pick_engine(ep, engine)
    workdir = f"tts_{ep}"
    print(f"[1/4] TTS 生成解说句…（引擎: {engine}"
          + ("，音色=ref_voice.wav 克隆" if engine == "f5" else f"，音色={cfg['voice']}") + "）")
    tts_dispatch(ep, cfg, workdir, engine)

    print("[2/4] 拼装解说轨…")
    # 视频时长从成片读取
    probe = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", f"out/{ep}.mp4"],
        capture_output=True, text=True)
    total = float(probe.stdout.strip())
    N = int(total * SR)
    narr = np.zeros((N, 2), np.float32)
    env = np.zeros(N, np.float32)
    for i, line in enumerate(cfg["lines"]):
        seg = mp3_to_f32(_sentence_path(workdir, i))
        i0 = int(line["t"] * SR)
        i1 = min(i0 + len(seg), N)
        if i1 <= i0: continue
        narr[i0:i1] += seg[:i1 - i0]
        env[i0:i1] = np.maximum(env[i0:i1], 1.0)
    # 闪避包络：解说出现后保持到句尾+0.4s，平滑过渡
    from scipy.ndimage import maximum_filter1d, uniform_filter1d
    env = maximum_filter1d(env, size=int(0.4 * SR))
    env = uniform_filter1d(env, size=int(0.5 * SR))
    env = np.clip(env, 0, 1)

    print("[3/4] 与背景乐混音（解说时音乐闪避到 30%）…")
    # 读取背景乐
    raw = subprocess.run(
        ["ffmpeg", "-loglevel", "error", "-i", f"soundtrack_{ep}.wav", "-f", "s16le",
         "-ar", str(SR), "-ac", "2", "-"],
        capture_output=True, check=True).stdout
    music = np.frombuffer(raw, np.int16).astype(np.float32).reshape(-1, 2) / 32767.0
    if len(music) < N:
        music = np.pad(music, ((0, N - len(music)), (0, 0)))
    music = music[:N]
    ducked = music * ((1.0 - 0.7 * env)[:, None])  # 解说时音乐降到 30%
    mix = ducked + narr * 1.0
    # 解说峰值控制
    peak = np.abs(mix).max()
    if peak > 0.97:
        mix *= 0.97 / peak

    mixed_wav = f"narration_mix_{ep}.wav"
    with wave.open(mixed_wav, "wb") as wf:
        wf.setnchannels(2); wf.setsampwidth(2); wf.setframerate(SR)
        wf.writeframes((np.clip(mix, -1, 1) * 32767).astype(np.int16).tobytes())

    print("[4/4] 与视频合成…")
    out = f"out/{ep}_narrated.mp4"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error",
                    "-i", f"out/{ep}.mp4", "-i", mixed_wav,
                    "-map", "0:v:0", "-map", "1:a:0",
                    "-c:v", "copy", "-c:a", "aac", "-b:a", "256k",
                    "-movflags", "+faststart", out], check=True)
    print(f"DONE -> {out}")

if __name__ == "__main__":
    _ep = sys.argv[1] if len(sys.argv) > 1 else "ep01"
    _engine = sys.argv[2] if len(sys.argv) > 2 else None
    main(_ep, _engine)
