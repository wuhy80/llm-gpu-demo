# -*- coding: utf-8 -*-
"""《大模型原理》系列共享视觉语言。
所有分集场景必须使用这里的原语，保证 12 集风格统一：
发光 Token 方块（系列主角）/ 概率分布条 / 注意力连线 / 损失曲线 / 嵌入点云 / 模型层堆栈 / 对话气泡
"""
import numpy as np
from PIL import Image, ImageDraw
from common import (W, H, LW, LH, Trails, comp_add, comp_glow_text, sprite_scale,
                    text_sprite, eq_sprite, palette_stops, resize_f, resize_rgb,
                    blur_f, blur_rgb, fade_win, clamp01, ease_io, ease_out,
                    uv_grid, NOISE, XX, YY)

def poly_lr(buf, pts, color, inten=1.0, step=0.7):
    """画辉光折线。buf 可为低分辨率 ndarray 或 Trails 对象"""
    pts = np.asarray(pts, np.float32)
    if pts.ndim != 2 or len(pts) < 2:
        return buf
    seglen = np.linalg.norm(np.diff(pts, axis=0), axis=1)
    total = seglen.sum() + 1e-6
    n = max(2, int(total / step))
    u = np.linspace(0, len(pts) - 1, n)
    xs = np.interp(u, np.arange(len(pts)), pts[:, 0])
    ys = np.interp(u, np.arange(len(pts)), pts[:, 1])
    if isinstance(buf, Trails):
        buf.splat(xs, ys, color, inten)
        return
    tr = Trails(buf.shape[1], buf.shape[0], 1.0)
    tr.buf[:] = 0
    tr.splat(xs, ys, color, inten)
    buf += tr.buf

# ---------------- Token 方块（系列主角） ----------------
def _has_cjk(s):
    return any('一' <= ch <= '鿿' or ch in '，。：；！？「」（）' for ch in str(s))

def token_block_sprite(text, box=88, color=(0.45, 0.75, 1.0), fill=0.16,
                       font_size=None, corner=14):
    """发光 token 方块精灵（RGBA float）。text 会自动缩放进方块。CJK 自动用中文字体。"""
    pad = 6
    S = box + pad * 2
    im = Image.new("L", (S, S), 0)
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([pad, pad, pad + box, pad + box], radius=corner, outline=255, width=3)
    arr = np.asarray(im, np.float32) / 255
    sprite = np.zeros((S, S, 4), np.float32)
    for c in range(3):
        sprite[..., c] = color[c] * (arr * 0.85)
        sprite[..., c] += color[c] * arr * 0  # 保留边框结构
    sprite[..., 3] = arr
    # 内部微填充
    inner = np.asarray(Image.new("L", (S, S), 0), np.float32)
    di = ImageDraw.Draw(im)
    di.rounded_rectangle([pad + 4, pad + 4, pad + box - 4, pad + box - 4],
                         radius=max(4, corner - 6), fill=90)
    inner = np.asarray(im, np.float32) / 255 - arr
    inner = np.clip(inner, 0, 1)
    for c in range(3):
        sprite[..., c] += color[c] * inner * fill * 2
    # 文字（白色，自动缩放）
    fs = font_size or int(box * 0.40)
    fkey = "cn_light" if _has_cjk(text) else "lat_semi"
    spr = text_sprite(text, fkey, fs, (245, 248, 255), tracking=0)
    if spr.shape[0] > box * 0.62 or spr.shape[1] > box * 0.86:
        k = min(box * 0.62 / spr.shape[0], box * 0.86 / spr.shape[1])
        spr = sprite_scale(spr, k)
    h2, w2 = spr.shape[:2]
    tex = np.zeros((S, S, 4), np.float32)
    oy = max(0, (S - h2) // 2); ox = max(0, (S - w2) // 2)
    h2c = min(h2, S - oy); w2c = min(w2, S - ox)
    tex[oy:oy + h2c, ox:ox + w2c] = spr[:h2c, :w2c]
    a2 = tex[..., 3:4]
    sprite[..., :3] += tex[..., :3] * a2 * 1.1
    sprite[..., 3:4] = np.maximum(sprite[..., 3:4], a2)
    return sprite

def token_stream(canvas_lr, t, tokens, y, speed=90, box=64, colors=None,
                 x_start=0.0, spacing=1.25, glow=1.0):
    """一排 token 方块向左流动（低分辨率画布）。"""
    n = len(tokens)
    total = n * box * spacing
    sprites = []
    for i, tk in enumerate(tokens):
        col = colors[i] if colors is not None else (0.45, 0.75, 1.0)
        sprites.append(token_block_sprite(str(tk), box, col))
    for i, spr in enumerate(sprites):
        x = (x_start + i * box * spacing - t * speed) % (total + box * 2) - box
        comp_add(canvas_lr, spr, x + box, y, gain=glow)
    return canvas_lr

def token_row_static(canvas, tokens, cx, cy, box=88, gap=18, colors=None,
                     alpha=1.0, gains=None, highlight=None, hl_color=(1.0, 0.85, 0.4)):
    """静态 token 方块行（全分辨率画布），highlight=高亮索引列表"""
    n = len(tokens)
    total = n * box + (n - 1) * gap
    x0 = cx - total / 2 + box / 2
    for i, tk in enumerate(tokens):
        col = colors[i] if colors is not None else (0.45, 0.75, 1.0)
        if highlight is not None and i in highlight:
            col = hl_color
        spr = token_block_sprite(str(tk), box, col)
        g = gains[i] if gains is not None else 1.0
        comp_add(canvas, spr, x0 + i * (box + gap), cy, alpha=alpha, gain=g)
    return canvas

# ---------------- 概率分布条 ----------------
def prob_bars(canvas, items, cx, cy, bar_w=560, bar_h=26, gap=16, t=0.0,
              reveal=1.0, chosen=None, label_size=30, val_size=26):
    """概率分布条。items: [(label, prob, color), ...]，chosen=选中索引"""
    total_h = len(items) * (bar_h + gap) - gap
    y0 = cy - total_h / 2
    for i, (lab, p, col) in enumerate(items):
        g = ease_out(clamp01(reveal * len(items) - i))
        if g <= 0.01:
            continue
        y = y0 + i * (bar_h + gap) + bar_h / 2
        # 标签
        spr = text_sprite(lab, "cn_light" if _has_cjk(lab) else "lat_semi",
                          label_size, (225, 232, 250), tracking=1)
        comp_add(canvas, spr, cx - bar_w / 2 - 130, y, alpha=g)
        # 条
        w = bar_w * clamp01(p / max(max(x[1] for x in items), 1e-6)) * g
        if w > 2:
            tr = Trails(LW, LH, 1.0); tr.buf[:] = 0
            xx = np.linspace((cx - bar_w / 2) / 3, (cx - bar_w / 2 + w) / 3,
                             max(2, int(w / 3)))
            inten = 2.0 if chosen is not None and i == chosen else 1.5
            tr.splat(xx, np.full(len(xx), y / 3), col, inten)
            canvas += resize_rgb(blur_rgb(tr.buf, 1.0), W, H) * 1.15
        # 百分比
        vs = text_sprite(f"{p*100:.0f}%", "lat_semi", val_size,
                         (255, 225, 160) if chosen == i else (200, 210, 235), tracking=1)
        comp_add(canvas, vs, cx - bar_w / 2 + max(w, 8) + 60, y, alpha=g * min(1, p * 8 + 0.3))
    return canvas

def softmax(logints, temperature=1.0):
    x = np.asarray(logints, np.float64) / max(temperature, 1e-6)
    x -= x.max()
    e = np.exp(x)
    return e / e.sum()

# ---------------- 注意力连线 ----------------
def attention_line(canvas, p1, p2, weight, color=(0.55, 0.8, 1.0), t=0.0, width=2.2):
    """词与词之间的注意力弧线（辉光），weight 0..1"""
    if weight <= 0.03:
        return
    p1 = np.array(p1, float); p2 = np.array(p2, float)
    mid = (p1 + p2) / 2 - np.array([0, 40 + 130 * weight])
    th = np.linspace(0, 1, 60)
    pts = ((1 - th)[:, None] ** 2 * p1 + 2 * (1 - th)[:, None] * th[:, None] * mid +
           th[:, None] ** 2 * p2)
    shift = np.sin(th * 6 - t * 5) * 2.2 * weight
    pts[:, 1] += shift
    poly_lr(canvas, pts, color, 0.4 + 1.5 * weight)

def word_row_positions(words, cx, cy, word_w=96, gap=14):
    """返回词与词中心坐标（用于注意力连线端点）"""
    total = len(words) * word_w + (len(words) - 1) * gap
    x0 = cx - total / 2 + word_w / 2
    return [(x0 + i * (word_w + gap), cy) for i in range(len(words))]

# ---------------- 损失曲线 ----------------
def loss_curve(canvas, progress, x0=380, y0=760, w=1150, h=380, seed=3,
               color=(1.0, 0.62, 0.3), axes=True):
    """预训练 loss 下降曲线（带噪声）。canvas 可以是低分辨率 ndarray 或 Trails"""
    rng = np.random.default_rng(seed)
    n = 240
    xs = np.linspace(0, 1, n)
    base = 1.6 * np.exp(-2.2 * xs) + 0.32
    noise = rng.normal(0, 0.022, n) * np.exp(-xs * 1.2) + 0.008
    ys = base + noise
    ys = np.clip(ys, 0.12, 2.0)
    m = max(2, int(n * clamp01(progress)))
    pts = np.stack([x0 + xs[:m] * w, y0 - ys[:m] / 2.0 * h], 1)
    if axes:
        poly_lr(canvas, [(x0, y0), (x0 + w, y0)], (0.5, 0.55, 0.7), 0.3)
        poly_lr(canvas, [(x0, y0), (x0, y0 - h - 20)], (0.5, 0.55, 0.7), 0.3)
    poly_lr(canvas, pts, color, 1.0)
    if m > 0 and progress < 1.0:
        poly_lr(canvas, [(pts[-1, 0], pts[-1, 1])] * 2, (1.0, 0.9, 0.6), 2.2, step=1.2)
    return canvas

# ---------------- 嵌入空间点云 ----------------
def point_cloud(canvas_lr, t, n=420, seed=5, colors=None, spread=1.0,
                center=(LW * 0.5, LH * 0.5), swirl=0.15, size_scale=1.0):
    """嵌入空间点云：语义相近的点成簇漂移"""
    rng = np.random.default_rng(seed)
    n_clusters = 7
    cc = rng.uniform(-1, 1, (n_clusters, 2)) * np.array([LW * 0.4, LH * 0.38]) * spread
    pts = []
    cols = []
    pal = colors or [(0.4, 0.7, 1.0), (0.75, 0.5, 1.0), (0.4, 0.95, 0.8),
                     (1.0, 0.75, 0.4), (1.0, 0.5, 0.8), (0.6, 0.9, 0.45), (0.55, 0.6, 1.0)]
    for k in range(n_clusters):
        m = n // n_clusters
        pts.append(cc[k] + rng.normal(0, 34 * spread, (m, 2)))
        cols.append(np.tile(pal[k % len(pal)], (m, 1)))
    P = np.concatenate(pts); C = np.concatenate(cols)
    # 慢速旋涡漂移
    ang = t * swirl
    R = np.array([[np.cos(ang), -np.sin(ang)], [np.sin(ang), np.cos(ang)]])
    P = P @ R.T + np.array([center[0], center[1]])
    tw = 0.55 + 0.45 * np.sin(t * 1.6 + rng.uniform(0, 6.28, len(P)))
    tr = Trails(LW, LH, 1.0); tr.buf[:] = 0
    tr.splat(P[:, 0], P[:, 1], C, tw * 0.8 * size_scale)
    full = (getattr(canvas_lr, 'shape', (0,))[0] == H)
    if full:
        canvas_lr += resize_rgb(tr.buf, W, H) * 0.9
    else:
        canvas_lr += tr.buf * 0.9
    return canvas_lr

# ---------------- Transformer 层堆栈 ----------------
def layer_stack(canvas, t, n_layers=6, cx=W / 2, cy=560, w=560, gap=52, tilt=0.86):
    """模型层堆栈：倾斜的玻璃板层叠，数据流光点穿过"""
    for i in range(n_layers):
        y = cy + (i - (n_layers - 1) / 2) * gap
        k = 1 - abs(i - (n_layers - 1) / 2) / n_layers * 0.25
        ww = w * (1 - i * 0.02)
        # 玻璃板
        im = Image.new("L", (W, H), 0)
        d = ImageDraw.Draw(im)
        d.rounded_rectangle([cx - ww / 2, y - 14 * tilt, cx + ww / 2, y + 14 * tilt],
                            radius=12, outline=255, width=2)
        arr = np.asarray(im, np.float32) / 255
        sm = blur_f(resize_f(arr, LW, LH), 2)
        col = palette_stops([(0, (0.4, 0.65, 1.0)), (0.5, (0.65, 0.5, 1.0)), (1, (0.45, 0.9, 1.0))],
                            i / max(n_layers - 1, 1))
        canvas += resize_rgb(np.stack([sm * col[0], sm * col[1], sm * col[2]], -1), W, H) * 0.75
        canvas += arr[..., None] * np.array(col) * 0.35
    # 穿层光点
    tr = Trails(LW, LH, 0.9)
    for k in range(5):
        p = ((t * 0.55 + k * 0.2) % 1.0)
        y = cy - (n_layers - 1) / 2 * gap + p * (n_layers - 1) * gap
        xx = cx + np.sin(p * 9 + k * 2.4) * w * 0.28
        tr.splat([xx / 3], [y / 3], (1.0, 0.95, 0.75), 1.5)
    canvas += resize_rgb(tr.buf, W, H) * 0.9
    return canvas

# ---------------- 对话气泡 ----------------
def chat_bubble(canvas, text, is_user, cx, cy, w=760, t_in=1.0, size=27):
    """极简对话气泡。is_user=True 右侧灰蓝，False 左侧深色描边"""
    spr_text = text_sprite(text, "cn_light", size, (235, 240, 252), tracking=2)
    tw = min(w, spr_text.shape[1] + 90)
    th = max(spr_text.shape[0] + 56, 96)
    im = Image.new("L", (W, H), 0)
    d = ImageDraw.Draw(im)
    x0 = cx - tw / 2; y0 = cy - th / 2
    d.rounded_rectangle([x0, y0, x0 + tw, y0 + th], radius=26,
                        outline=255, width=2 if not is_user else 0, fill=100 if is_user else 26)
    arr = (np.asarray(im, np.float32) / 255) * t_in
    sm = blur_f(resize_f(arr, LW, LH), 1.6)
    col = (0.5, 0.62, 0.85) if is_user else (0.42, 0.72, 1.0)
    canvas += resize_rgb(np.stack([sm * col[0], sm * col[1], sm * col[2]], -1), W, H) * 0.85
    comp_add(canvas, spr_text, cx, cy, alpha=t_in)
    return canvas

# ---------------- 打字机光标 ----------------
def cursor(canvas, x, y, t, h=44, color=(0.75, 0.95, 1.0)):
    a = 0.5 + 0.5 * np.sin(t * 7)
    if a > 0.25:
        tr = Trails(LW, LH, 1.0); tr.buf[:] = 0
        tr.splat([x / 3], [(y) / 3 + np.linspace(-h / 3, h / 3, 12)], color, a * 1.4)
        canvas += resize_rgb(tr.buf, W, H)
    return canvas

# ---------------- 生成循环环形流程 ----------------
def generation_loop(canvas, t, cx, cy, R=250, stages=("句子", "模型", "概率", "采样", "追加")):
    """环形流程图：五个节点 + 旋转光点沿环流动"""
    n = len(stages)
    pos = []
    for i, s in enumerate(stages):
        a = -np.pi / 2 + i * 2 * np.pi / n
        px, py = cx + np.cos(a) * R, cy + np.sin(a) * R * 0.82
        pos.append((px, py))
        spr = token_block_sprite(s, 92, (0.5, 0.75, 1.0))
        comp_add(canvas, spr, px, py, gain=1.05)
    # 弧线连接
    for i in range(n):
        p1, p2 = pos[i], pos[(i + 1) % n]
        th = np.linspace(0, 1, 50)
        a1 = -np.pi / 2 + i * 2 * np.pi / n
        a2 = a1 + 2 * np.pi / n
        arc = np.stack([cx + np.cos(np.linspace(a1 + 0.22, a2 - 0.22, 50)) * R,
                        cy + np.sin(np.linspace(a1 + 0.22, a2 - 0.22, 50)) * R * 0.82], 1)
        poly_lr(canvas, arc, (0.5, 0.7, 1.0), 0.45)
    # 流动光点
    tr = Trails(LW, LH, 0.92)
    a = (t * 0.5) % (2 * np.pi)
    for k in range(3):
        aa = a + k * 2.1
        tr.splat([(cx + np.cos(aa) * R) / 3], [(cy + np.sin(aa) * R * 0.82) / 3], (1.0, 0.9, 0.6), 1.8)
    canvas += resize_rgb(tr.buf, W, H) * 0.95
    return canvas, pos

# ---------------- 全系列共用叠层 ----------------
def caption(canvas, t, dur, main, sub=None, y=966, main_size=30, delay=0.6):
    """底部字幕：淡入淡出（与量子片同款式）"""
    a = fade_win(t - delay, max(dur - delay - 0.4, 0.1), 0.9, 0.8)
    if a <= 0.01:
        return canvas
    spr = text_sprite(main, "cn_light", main_size, (235, 240, 255), tracking=8)
    comp_glow_text(canvas, spr, W // 2, y, alpha=a * 0.92, gain=1.0, halo=0.4, radius=6)
    if sub:
        spr2 = text_sprite(sub, "cn_light", 21, (150, 165, 200), tracking=6)
        comp_glow_text(canvas, spr2, W // 2, y + 52, alpha=a * 0.8, gain=0.9, halo=0.3, radius=5)
    return canvas

def chapter_card(canvas, t, num, zh, lat=""):
    """分集内章节卡片：t 为局部时间，0.2s入 5s内退出"""
    if t < 0.15 or t > 5.2:
        return canvas
    a = fade_win(t - 0.15, 4.9, 0.9, 1.0)
    if a <= 0.01:
        return canvas
    dy = (1 - ease_out(clamp01((t - 0.15) / 1.4))) * 26
    spr0 = text_sprite(num, "dengl", 150, (110, 130, 200), tracking=0)
    comp_glow_text(canvas, spr0, W // 2, 300 + dy, alpha=a * 0.4, gain=1.0, halo=0.5, radius=10)
    spr1 = text_sprite(zh, "cn_light", 84, (240, 244, 255), tracking=36)
    comp_glow_text(canvas, spr1, W // 2, 470 + dy, alpha=a * 0.95, gain=1.05, halo=0.5, radius=9)
    if lat:
        spr2 = text_sprite(lat, "lat_light", 26, (150, 165, 205), tracking=16)
        comp_add(canvas, spr2, W // 2, 575 + dy, alpha=a * 0.85, gain=0.9)
    lw = 300 * ease_out(clamp01((t - 0.4) / 1.6))
    if lw > 4:
        ln = Trails(LW, LH, 1.0); ln.buf[:] = 0
        ln.splat(np.linspace(W / 2 - lw / 3, W / 2 + lw / 3, 60),
                 np.full(60, (600 + dy) / 3), (0.75, 0.8, 1.0), a * 0.9)
        if canvas.shape[0] == H:
            canvas += resize_rgb(ln.buf, W, H) * 0.5
        else:
            canvas += ln.buf * 0.5
    return canvas

def ep_marker(canvas, t, dur, ep_no, ep_title):
    """左上角系列角标"""
    a = fade_win(t, dur, 1.2, 1.2) * 0.75
    if a <= 0.02:
        return canvas
    spr = text_sprite(f"EP.{ep_no:02d} · 大模型原理 | {ep_title}", "cn_light", 22,
                      (140, 152, 190), tracking=4)
    comp_add(canvas, spr, 240, 84, alpha=a)
    return canvas
