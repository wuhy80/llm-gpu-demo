# -*- coding: utf-8 -*-
"""《大模型原理》参数化配乐系统。
用法: python runtime.py ep01 music  （读取 episodes/ep01.py 的 MUSIC 配置）
输出: soundtrack_ep01.wav + beats_ep01.json
设计原则与量子片一致：低频深邃、80BPM 卡点、转场为低通下扫+深boom（8kHz 以上能量为零）。
"""
import json
import numpy as np
from scipy.signal import fftconvolve

SR = 44100
NOTE = dict(C1=32.70, D1=36.71, E1=41.20, F1=43.65, G1=49.00, A1=55.00, B1=61.74,
            C2=65.41, D2=73.42, E2=82.41, F2=87.31, G2=98.00, A2=110.00, B2=123.47,
            C3=130.81, D3=146.83, E3=164.81, F3=174.61, G3=196.00, A3=220.00, B3=246.94,
            C4=261.63, D4=293.66, E4=329.63, F4=349.23, G4=392.00, A4=440.00, B4=493.88,
            C5=523.25, D5=587.33, E5=659.26, F5=698.46, G5=783.99, A5=880.00, B5=987.77,
            C6=1046.5, D6=1174.7)
NOTE["C#3"] = 138.59; NOTE["C#5"] = 554.37; NOTE["G#3"] = 207.65; NOTE["F#3"] = 185.00

CHORDS = {  # 小调家族（A 小调与 D 小调两套）
    "Am": ["A2", "C3", "E3", "A1"], "F": ["F2", "A2", "C3", "F1"],
    "C": ["C3", "E3", "G3", "C2"], "G": ["G2", "B2", "D3", "G1"],
    "Dm": ["D3", "F3", "A3", "D2"], "Bb": ["Bb2", "D3", "F3", "Bb1"],
    "Gm": ["G2", "Bb2", "D3", "G1"], "A": ["A2", "C#3", "E3", "A1"],
    "Em": ["E2", "G2", "B2", "E1"],
    "E": ["E2", "G#2", "B2", "E1"],
}
NOTE["G#2"] = 103.83; NOTE["Bb2"] = 116.54; NOTE["Bb1"] = 58.27; NOTE["B2"] = 123.47


def render_soundtrack(mod, shots=None, out_prefix=None):
    name = mod.__name__.split(".")[-1]
    out_prefix = out_prefix or name
    M = mod.MUSIC
    if shots is None:
        shots, t = [], 0.0
        for s in mod.SCENES:
            shots.append(dict(s, start=t, end=t + s["dur"]))
            t += s["dur"]
    total = sum(s["dur"] for s in shots)
    beats = M.get("beat", 0.75)
    bar = beats * 4
    prog = M["chords"]           # 和弦进行（按小节循环）
    rng = np.random.default_rng(M.get("seed", 42))
    N = int(total * SR)

    # ---------- 工具 ----------
    def rc_ramp(n, rise):
        w = np.ones(n)
        r = min(int(rise * SR), n // 2)
        if r > 0:
            edge = 0.5 - 0.5 * np.cos(np.pi * np.arange(r) / r)
            w[:r] = edge; w[-r:] = edge[::-1]
        return w

    def env_ad(t0, attack, decay, curve=4.0):
        e = np.zeros(N)
        i0 = int(t0 * SR)
        if i0 >= N: return e
        tt = np.arange(N - i0) / SR
        e[i0:] = np.clip(tt / max(attack, 1e-4), 0, 1) * np.exp(-curve * tt / decay)
        return e

    def fft_lp(x, fc, order=1.6):
        X = np.fft.rfft(x)
        f = np.fft.rfftfreq(len(x), 1 / SR)
        return np.fft.irfft(X * (1.0 / (1.0 + (f / max(fc, 1.0)) ** (2 * order))), len(x))

    def brown(n):
        x = np.cumsum(rng.standard_normal(n))
        x -= np.linspace(x[0], x[-1], n)
        return x / (np.abs(x).max() + 1e-9)

    def place(dst, seg, t0):
        i0 = int(t0 * SR)
        i1 = min(i0 + len(seg), len(dst))
        if i0 < len(dst):
            dst[i0:i1] += seg[: i1 - i0]

    def saw_ish(f, dur, det=1.0, nh=7):
        tt = np.arange(int(dur * SR)) / SR
        x = np.zeros(len(tt))
        for k in range(1, nh + 1):
            x += np.sin(2 * np.pi * f * det * k * tt + rng.uniform(0, 6.28)) / k
        return x * 0.33

    # ---------- 和弦小节表 ----------
    n_bars = int(np.ceil(total / bar))
    bar_chord = [prog[b % len(prog)] for b in range(n_bars)]
    # 每小节能量：由场景能量插值
    bar_t = np.arange(n_bars) * bar + bar / 2
    scene_t = [s["start"] + s["dur"] / 2 for s in shots]
    scene_e = [s["energy"] for s in shots]
    bar_e = np.interp(bar_t, scene_t, scene_e)

    pad_bus = np.zeros(N); bass_bus = np.zeros(N)
    arpL = np.zeros(N); arpR = np.zeros(N)
    bell_bus = np.zeros(N); lead_bus = np.zeros(N); kick_bus = np.zeros(N)
    sub_bus = np.zeros(N)

    pad_dur = bar + 0.4
    for b in range(n_bars):
        tb = b * bar
        notes = CHORDS[bar_chord[b]]
        f0, f1, f2, fb = [NOTE[x] for x in notes]
        e = float(bar_e[b])
        gain = 0.085 + 0.185 * e
        w = rc_ramp(int(pad_dur * SR), 0.9)
        seg = (saw_ish(f0, pad_dur, 0.9985) + saw_ish(f1, pad_dur, 1.0018) +
               0.8 * saw_ish(f2, pad_dur, 0.999))
        place(pad_bus, seg * w * gain, tb)
        bseg = np.sin(2 * np.pi * fb * np.arange(int(pad_dur * SR)) / SR)
        bseg += 0.35 * np.sin(2 * np.pi * fb * 2 * np.arange(int(pad_dur * SR)) / SR)
        place(bass_bus, np.tanh(bseg * 1.5) * 0.6 * w[:len(bseg)] * (0.16 + 0.14 * e), tb)
        # 钟琴（低能量段落）
        if e < 0.45 and rng.random() < 0.5:
            pool = [n for n in ("D5", "F5", "A5", "C6", "E5") if n in NOTE]
            f = NOTE[pool[rng.integers(0, len(pool))]]
            tt = np.arange(int(3.0 * SR)) / SR
            s = (np.sin(2 * np.pi * f * tt) + 0.4 * np.sin(2 * np.pi * f * 2.01 * tt)) * \
                np.exp(-tt * 1.6) * np.clip(tt / 0.004, 0, 1) * 0.5
            place(bell_bus, s * (1 - (b % 3) * 0.2), tb + rng.uniform(0, bar * 0.5))
            place(bell_bus, s * ((b % 3) * 0.2 + 0.3), tb + rng.uniform(0, bar * 0.5) + 0.012)

    # pluck 定义（供琶音）
    def pluck(f, dur=0.3):
        tt = np.arange(int(dur * SR)) / SR
        x = np.sin(2 * np.pi * f * tt) + 0.3 * np.sin(2 * np.pi * 2 * f * tt) + \
            0.12 * np.sin(2 * np.pi * 3 * f * tt)
        return x * np.clip(tt / 0.002, 0, 1) * np.exp(-tt * 11) * 0.28

    # ---------- 琶音（整轨重画，保证时值准确） ----------
    arpL[:] = 0; arpR[:] = 0
    for b in range(n_bars):
        tb = b * bar
        e = float(bar_e[b])
        if e <= 0.3: continue
        notes = CHORDS[bar_chord[b]]
        f0, f1, f2 = [NOTE[x] for x in notes[:3]]
        tones = [f0, f1, f2, f0 * 2, f2, f1 * 2, f0 * 2, f2]
        st = beats / 2
        for i in range(8):
            f = tones[i]
            s = pluck(f)
            pan = 0.5 + 0.35 * np.sin(i * 1.1 + b)
            g = (0.30 if e > 0.6 else 0.22) * (0.8 + 0.2 * (i % 4 == 0))
            place(arpL, s * g * (1 - pan * 0.6), tb + i * st)
            place(arpR, s * g * (0.4 + pan * 0.6), tb + i * st)
    d1 = int(beats * 0.75 * SR)
    arpL = fft_lp(arpL + 0.32 * np.roll(arpR, d1) + 0.14 * np.roll(arpL, 2 * d1), 2400)[:N]
    arpR = fft_lp(arpR + 0.32 * np.roll(arpL, d1) + 0.14 * np.roll(arpR, 2 * d1), 2400)[:N]

    # ---------- Kick ----------
    kick_times = []
    for b in range(n_bars):
        tb = b * bar
        e = float(bar_e[b])
        if e >= 0.62:
            pat = [(0, 1.0), (beats, 0.55), (2 * beats, 0.9), (3 * beats, 0.55)]
        elif e >= 0.42:
            pat = [(0, 0.9), (2 * beats, 0.65)]
        elif e >= 0.25:
            pat = [(0, 0.75)]
        else:
            pat = []
        for off, g in pat:
            kick_times.append((tb + off, g))
    def kick_seg(strength):
        tt = np.arange(int(0.5 * SR)) / SR
        f = 95 * np.exp(-tt * 16) + 42
        ph = 2 * np.pi * np.cumsum(f) / SR
        return np.sin(ph) * np.clip(tt / 0.004, 0, 1) * np.exp(-tt * 7.5) * strength
    duck = np.zeros(N)
    kd = kick_seg(1.0)
    for kt, g in kick_times:
        place(kick_bus, kick_seg(g), kt)
        place(duck, kd / kd.max() * 0.5 * g, kt)
    duck = fft_lp(duck, 8)

    # ---------- Sub 铺底 ----------
    tt_all = np.arange(N) / SR
    sub_bus = np.sin(2 * np.pi * NOTE[M.get("sub", "A1")] * tt_all +
                     0.3 * np.sin(2 * np.pi * 0.11 * tt_all)) * \
              0.05 * (0.6 + 0.4 * np.sin(2 * np.pi * tt_all / 13.0))

    # ---------- 主旋律（可选） ----------
    for t0, dur, nm in M.get("melody", []):
        f = NOTE[nm]
        tt = np.arange(int((dur + 0.4) * SR)) / SR
        x = np.zeros(len(tt))
        for k in range(1, 9):
            x += np.sin(2 * np.pi * f * k * tt) / k
        w = np.clip(tt / 0.25, 0, 1) * np.exp(-np.clip(tt - dur, 0, None) * 3.5) * \
            rc_ramp(len(tt), 0.05)
        place(lead_bus, x * w * 0.16, t0)
    lead_bus = fft_lp(lead_bus, 1800, 1.4)

    # ---------- 混响 ----------
    ir_len = int(2.2 * SR)
    ir_t = np.arange(ir_len) / SR
    ir = brown(ir_len) * np.exp(-ir_t * 2.1)
    ir = fft_lp(ir, 3000, 1.5); ir /= np.abs(ir).max()
    def rev(x, wet=0.3):
        return x + wet * fftconvolve(x, ir)[: len(x)]
    pad_bus = fft_lp(pad_bus, 1400, 1.2)
    padL = rev(np.roll(pad_bus, int(0.011 * SR)) * (1 - 0.38 * fft_lp(duck, 8)), 0.32)
    padR = rev(pad_bus * (1 - 0.38 * fft_lp(duck, 8)), 0.32)
    bass_bus *= (1 - 0.30 * fft_lp(duck, 8))
    bell_bus = rev(fft_lp(bell_bus * 0.10, 6500, 1.5), 0.55)
    lead_bus = rev(lead_bus, 0.38)
    arpL = rev(arpL, 0.22); arpR = rev(arpR, 0.22)

    # ---------- 转场 whoosh + boom ----------
    fxL = np.zeros(N); fxR = np.zeros(N)
    chapter_starts = [s["start"] for s in shots if s.get("chapter")]
    def whoosh_boom(t0, big=False, small=False):
        dur = 2.0
        n = int(dur * SR)
        tt = np.arange(n) / SR
        p = tt / dur
        g = np.exp(-((p - 0.82) / 0.34) ** 2) * (1 + 0.25 * np.sin(2 * np.pi * (2 + 6 * p) * tt))
        wl = fft_lp(brown(n), 550 if not small else 420, 1.6)
        wr = fft_lp(brown(n), 550 if not small else 420, 1.6)
        base = 0.34 if small else (0.55 if big else 0.44)
        segL, segR = wl * g * base, wr * g * base
        f_sw = 40 + 260 * (1 - p) ** 2.2
        dive = np.sin(2 * np.pi * np.cumsum(f_sw) / SR) * g * 0.16
        segL += dive; segR += dive
        nb = int(1.9 * SR)
        tb = np.arange(nb) / SR
        f_b = 34 + 55 * np.exp(-tb * 7)
        boom = np.sin(2 * np.pi * np.cumsum(f_b) / SR) * \
               np.clip(tb / 0.005, 0, 1) * np.exp(-tb * 3.0)
        tail = fft_lp(brown(nb), 240, 1.4) * np.exp(-tb * 2.6) * 0.5
        bt = (boom * 0.9 + tail) * (0.5 if small else (0.95 if big else 0.72))
        place(segL, bt, 0); place(segR, bt, 0)
        return segL, segR
    for s in shots:
        if s["start"] <= 0: continue
        big = s.get("chapter", False) or s["start"] in M.get("big_booms", [])
        small = s.get("start") in M.get("small_booms", [])
        segL, segR = whoosh_boom(s["start"], big=big, small=small)
        place(fxL, segL, s["start"] - 2.0); place(fxR, segR, s["start"] - 2.0)
    for t0 in chapter_starts + M.get("big_booms", []):
        n = int(12.0 * SR)
        tt = np.arange(n) / SR
        p = tt / n
        g = p ** 2.6 * 0.4
        trem = 0.75 + 0.25 * np.sin(2 * np.pi * tt * (0.5 + 3.5 * p ** 2))
        rsL = fft_lp(brown(n), 500) * g * trem
        rsR = fft_lp(brown(n), 500) * g * trem
        f_up = 55 + 50 * p
        dive = np.sin(2 * np.pi * np.cumsum(f_up) / SR) * g * 0.20
        i0 = int((t0 - 12.0) * SR)
        if i0 < 0: continue
        n2 = min(n, N - i0)
        fxL[i0:i0 + n2] += rsL[:n2] + dive[:n2]
        fxR[i0:i0 + n2] += rsR[:n2] + dive[:n2]
    fxL = fft_lp(fxL, 2000, 1.2); fxR = fft_lp(fxR, 2000, 1.2)

    # ---------- 混音 ----------
    mixL = padL + bass_bus + arpL + bell_bus + lead_bus + kick_bus * 0.85 + sub_bus + fxL
    mixR = padR + bass_bus + arpR + bell_bus + lead_bus + kick_bus * 0.85 + sub_bus + fxR
    mixL = fft_lp(mixL, 12000, 1.0); mixR = fft_lp(mixR, 12000, 1.0)
    pre = max(np.abs(mixL).max(), np.abs(mixR).max())
    mixL *= 0.88 / pre; mixR *= 0.88 / pre
    mixL = np.tanh(mixL * 1.15) / np.tanh(1.15) * 0.88
    mixR = np.tanh(mixR * 1.15) / np.tanh(1.15) * 0.88
    pk = max(np.abs(mixL).max(), np.abs(mixR).max())
    mixL *= 0.95 / pk; mixR *= 0.95 / pk
    fi, fo = int(2.0 * SR), int(5.0 * SR)
    ramp_in = 0.5 - 0.5 * np.cos(np.pi * np.arange(fi) / fi)
    ramp_out = (0.5 + 0.5 * np.cos(np.pi * np.arange(fo) / fo)) ** 1.5
    mixL[:fi] *= ramp_in; mixR[:fi] *= ramp_in
    mixL[-fo:] *= ramp_out; mixR[-fo:] *= ramp_out

    import wave
    stereo = np.stack([mixL, mixR], 1)
    pcm = (np.clip(stereo, -1, 1) * 32767).astype(np.int16)
    with wave.open(f"soundtrack_{out_prefix}.wav", "wb") as wf:
        wf.setnchannels(2); wf.setsampwidth(2); wf.setframerate(SR)
        wf.writeframes(pcm.tobytes())

    kick_list = [round(t, 3) for t, _ in kick_times]
    meta = dict(bpm=60 / beats / 1 * (beats * 80 / 60), beat=beats, bar=bar,
                scene_starts=[s["start"] for s in shots][1:],
                chapter_starts=chapter_starts, kick_times=kick_list)
    meta["bpm"] = 60.0 / beats
    with open(f"beats_{out_prefix}.json", "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=1)

    def rms(x): return float(np.sqrt(np.mean(x ** 2)))
    print(f"soundtrack_{out_prefix}.wav  duration={len(mixL)/SR:.1f}s peak={pk:.2f}")
    for i, s in enumerate(shots):
        a, b = int(s["start"] * SR), int(min(s["end"], total) * SR)
        if b > a:
            print(f'  {s["name"]:<18} rms={rms(mixL[a:b]):.3f}')
