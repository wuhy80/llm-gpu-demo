#!/usr/bin/env bash
# EP01 51 秒验证样片一键脚本（Colab T4）：
# GPU 渲染 → 配乐 → 编码 → F5-TTS 克隆配音+混音 → 成品上传临时文件床（72h 有效）
# 用法: cd /content/work && bash run_demo.sh
set -e

echo "==============================================="
echo "[1/5] GPU 渲染 ep01_demo（51s = 1530 帧）..."
cd /content/work/gpu
python - <<'PY'
import os, time, torch
from PIL import Image
import truntime as T
T.set_device('cuda')
mod, shots, total = T.load_episode('ep01_demo')
os.makedirs('frames_ep01_demo', exist_ok=True)
tf = int(total * 30); t0 = time.time()
for i in range(tf):
    arr = T.render_by_time(mod, shots, min(i/30, total-0.1))
    Image.fromarray(arr).save(f'frames_ep01_demo/f{i:05d}.jpg', quality=92, subsampling=0)
    if i % 300 == 0:
        torch.cuda.synchronize()
        print(f'  render {i}/{tf}  {time.time()-t0:.0f}s', flush=True)
torch.cuda.synchronize()
el = time.time() - t0
print(f'render done: {tf} frames in {el:.0f}s -> {tf/el:.1f} fps (整集 10800 帧约 {10800/(tf/el)/60:.0f} 分钟)')
PY

echo "[2/5] 生成配乐（纯 numpy，秒级）..."
python - <<'PY'
import sys; sys.path.insert(0, '..')
import truntime as T
import make_music as MM
mod, shots, total = T.load_episode('ep01_demo')
MM.render_soundtrack(mod, shots)
print('soundtrack ok')
PY

echo "[3/5] 编码无声样片（约 1 分钟）..."
cd /content/work
mv -f gpu/soundtrack_ep01_demo.wav .
mkdir -p out
ffmpeg -y -loglevel error -framerate 30 -i gpu/frames_ep01_demo/f%05d.jpg \
  -i soundtrack_ep01_demo.wav \
  -c:v libx264 -preset medium -crf 17 -pix_fmt yuv420p -c:a aac -b:a 256k \
  -movflags +faststart out/ep01_demo.mp4
ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 out/ep01_demo.mp4

echo "[4/5] F5-TTS 克隆云健男声配音 + 混音（首跑下载模型约 1.35GB，2 句约 1 分钟）..."
python narrate.py ep01_demo

echo "[5/5] 上传成品到临时文件床（72 小时有效下载）..."
URL=$(curl -s -F "reqtype=fileupload" -F "time=72h" \
  -F "fileToUpload=@out/ep01_demo_narrated.mp4" \
  https://litterbox.catbox.moe/resources/internals/api.php)
if [[ ! "$URL" =~ ^https ]]; then
  echo "  litterbox 失败，改用 catbox（永久）..."
  URL=$(curl -s -F "reqtype=fileupload" \
    -F "fileToUpload=@out/ep01_demo_narrated.mp4" \
    https://catbox.moe/user/api.php)
fi
echo ""
echo "==============================================="
echo "RESULT_URL: $URL"
echo "（成品也在 /content/work/out/ep01_demo_narrated.mp4）"
echo "==============================================="
