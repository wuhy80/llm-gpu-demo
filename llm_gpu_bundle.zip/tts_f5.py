# -*- coding: utf-8 -*-
"""tts_f5 —— F5-TTS 音色克隆后端（开源 MIT，T4 友好）。

用法（由 narrate.py 调用）:
  from tts_f5 import f5_available, tts_lines_f5
  tts_lines_f5(cfg, workdir, ref_audio="ref_voice.wav", ref_text="...")

参考音频: 5-15 秒干净人声（无背景音乐）即可克隆音色；
ref_text 是参考音频里说的话（不提供则模型自动转写，首次稍慢）。
模型（SWivid/F5-TTS v1, ~1.35GB）首次运行自动从 HuggingFace 下载。
"""
import os


def f5_available():
    try:
        import f5_tts  # noqa: F401
        return True
    except Exception:
        return False


def tts_lines_f5(cfg, workdir, ref_audio, ref_text=None):
    """逐句生成 line_XX.wav（24kHz mono，由 narrate.py 统一重采样混音）。

    cfg: narration_<ep>.json 的内容（lines: [{t, text}], 可选 rate/speed）
    已存在的句子自动跳过（断点续跑）。
    """
    from f5_tts.api import F5TTS

    os.makedirs(workdir, exist_ok=True)
    speed = float(str(cfg.get("rate", "+4%")).replace("%", "").replace("+", "")) / 100.0 + 1.0

    # 延迟初始化（首次加载 + 可能的模型下载都发生在这里）
    api = F5TTS()

    ref_text_final = ref_text
    if not ref_text_final and os.path.exists("ref_text.txt"):
        ref_text_final = open("ref_text.txt", encoding="utf-8").read().strip()

    for i, line in enumerate(cfg["lines"]):
        out = os.path.join(workdir, f"line_{i:02d}.wav")
        if os.path.exists(out) and os.path.getsize(out) > 1000:
            print(f"  f5 line {i:02d} @ {line['t']}s (cached)", flush=True)
            continue
        # 固定逐句 seed：重跑同句结果可复现
        api.infer(ref_file=ref_audio, ref_text=ref_text_final or "",
                  gen_text=line["text"], file_wave=out,
                  speed=speed, seed=42 + i, show_info=lambda *_: None)
        print(f"  f5 line {i:02d} @ {line['t']}s", flush=True)
